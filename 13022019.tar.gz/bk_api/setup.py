import setuptools
from setuptools import setup


setup(
    name='bk_api',
    version='0.0.1',
    install_requires=['requests'],
    description='a pip-installable package example',
    license='MIT',
    packages=setuptools.find_packages(),
    author='Bruno Vinicius Avila Machado',
    author_email='brunovam@gmail.com',
    keywords=['example'],
    url='https://github.com'
)
