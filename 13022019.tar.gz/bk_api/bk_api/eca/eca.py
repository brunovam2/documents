import json
from functools import wraps
import inspect


ECA_URL = "/eca/v1"

def initializer(func):
    names, varargs, keywords, defaults = inspect.getargspec(func)

    @wraps(func)
    def wrapper(self, *args, **kargs):
        for name, arg in list(zip(names[1:], args)) + list(kargs.items()):
            setattr(self, name, arg)

        for name, default in zip(reversed(names), reversed(defaults)):
            if not hasattr(self, name):
                setattr(self, name, default)

        func(self, *args, **kargs)

    return wrapper


class EventType:
    id = None
    name = None

    @initializer
    def __init__(self, id=None, name=None):
        pass

    def get_url(self):
        return "%s/event_type/" % ECA_URL

class Event:
    id = None
    name = None

    @initializer
    def __init__(self, id=None, name=None):
        pass

    def get_url(self):
        return "%s/event/" % ECA_URL

class Condition:
    id = None
    nickname = None
    description = None
    filename = None
    function_name = None
    function_args = None

    @initializer
    def __init__(self, id=None, nickname=None, description=None, filename=None, function_name=None, function_args=None):
        pass

    def get_url(self):
        return "%s/condition/" % ECA_URL

class Action:
    id = None
    nickname = None
    description = None
    filename = None
    args = None
    env_args = None

    @initializer
    def __init__(self, id=None, nickname=None, description=None, filename=None, args=None, env_args=None):
        pass

    def get_url(self):
        return "%s/action/" % ECA_URL


class BatchEvent:
    id = None
    name = None
    e_type = None

    @initializer
    def __init__(self, id=None, name=None, e_type=None):
        pass

    def get_url(self):
        return "%s/batch_event/" % ECA_URL

class BatchRule:
    """
    ECA rule of a Batch
    """
    id = None
    batch = None
    event = None
    condition = None
    action = None

    @initializer
    def __init__(self, id=None, batch=None, event=None, condition=None, action=None):
        pass

    def get_url(self):
        return "%s/batch_rule/" % ECA_URL


class JobEvent:
    id = None
    name = None
    e_type = None

    @initializer
    def __init__(self, id=None, name=None, e_type=None):
        pass

    def get_url(self):
        return "%s/job_event/" % ECA_URL

class JobRule:
    """
    ECA rule of a Job
    """
    id = None
    job = None
    event = None
    condition = None
    action = None

    @initializer
    def __init__(self, id=None, job=None, event=None, condition=None, action=None):
        pass

    def get_url(self):
        return "%s/job_rule/" % ECA_URL


#class SchedulerEvent:
#    id = None
#    name = None
#
#    @initializer
#    def __init__(self, id=None, name=None):
#        pass
#
#    def get_url(self):
#        return "%s/scheduler_event/" % ECA_URL
#
#
#class SchedulerRule:
#    """
#    ECA rule of a Scheduler
#    """
#    # Um evento pode ser manutenção de servidores por exemplo, máquina que ficou
#    # indisponível, quando não tiver máquinas existentes suficientes para fazer
#    # processamentos e etc..
#    id = None
#    event = None
#    condition = None
#    action = None
#
#    @initializer
#    def __init__(self, id=None, event=None, condition=None, action=None):
#        pass
#
#    def get_url(self):
#        return "%s/scheduler_rule/" % ECA_URL
#
#
#class MonitoringEvent:
#    id = None
#    name = None
#
#    @initializer
#    def __init__(self, id=None, name=None):
#        pass
#
#    def get_url(self):
#        return "%s/monitoring_event/" % ECA_URL
#
#class MonitoringRule:
#    """
#    ECA rule of logs
#    """
#    id = None
#    monitoring = None
#    event = None
#    condition = None
#    action = None
#
#    @initializer
#    def __init__(self, id=None, monitoring=None, event=None, condition=None, action=None):
#        pass
#
#    def get_url(self):
#        return "%s/monitoring_rule/" % ECA_URL

class ObjectType:
    id = None
    name = None

    @initializer
    def __init__(self, id=None, name=None):
        pass

    def get_url(self):
        return "%s/object_type/" % ECA_URL

class ExecutionStatus:
    #SUCCESS
    #FAILED
    id = None
    name = None

    @initializer
    def __init__(self, id=None, name=None):
        pass

    def get_url(self):
        return "%s/execution_status/" % ECA_URL


class ExecutionHistory:
    id = None
    object_type = None
    object_id = None
    datetime = None
    status = None
    data = None

    @initializer
    def __init__(self, id=None, object_type=None, object_id=None, datetime=None, status=None, data=None):
        pass

    def get_url(self):
        return "%s/execution_history/" % ECA_URL

class Log:
    """
    Each log can be attached to an ECA rule. It stores every batch/job execution
    and related information
    """
    id = None
    object_type = None
    object_id = None
    event_id = None
    creation = None
    data = None
    verified_by_workflow = None

    @initializer
    def __init__(self, id=None, object_type=None, object_id=None, event_id=None, creation=None, data=None, verified_by_workflow=None):
        pass

    def get_url(self):
        return "%s/log/" % ECA_URL

class LogActionExecution:
    """
    This class is used to store the logs of actions execution.
    """
    action = None
    datetime = None
    log = None
    status = None
    output = None
    output_err = None
    status_code = None

    @initializer
    def __init__(self, action=None, datetime=None, log=None, status=None, output=None, output_err=None, status_code=None):
        pass

    def get_url(self):
        return "%s/log_action_execution/" % ECA_URL
