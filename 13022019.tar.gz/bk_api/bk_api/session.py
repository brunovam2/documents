#from scheduler.scheduler import Batch
#from parser.parse import Parser
import requests
import json


class BKSession():
    username = None
    password = None
    url = None
    session = None

    def __init__(self, username, password, url):
        self.username = username
        self.password = password
        self.url = url
        requests.packages.urllib3.disable_warnings()
        self.session = requests.Session()
        self.session.trust_env = False

    def get(self, obj):
        req_url = self.url+obj.get_url()
        if obj.id:
            req_url += "%s" % str(obj.id)
        print(req_url)
        r = self.session.get(req_url, verify=False)
        if r.status_code != 200:
            return r.text
        return r.json()


    def post(self, obj):
        req_url = self.url + obj.get_url()
        r = self.session.post(req_url, data=obj.__dict__, verify=False)
        return r.json()

    def put(self, obj):
        req_url = self.url + obj.get_url()
        if obj.id:
            req_url += "%s/" % str(obj.id)
        r = self.session.put(req_url, json=obj.__dict__, verify=False)
        return json.loads(r.json())

    def delete(self, obj):
        req_url = self.url + obj.get_url()
        if obj.id:
            req_url += "%s/" % str(obj.id)
        r = self.session.delete(req_url, verify=False)
        return r.status_code
