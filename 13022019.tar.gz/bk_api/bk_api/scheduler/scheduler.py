import json
from functools import wraps
import inspect


SCHEDULER_URL = "/scheduler/v1"

def initializer(func):
    names, varargs, keywords, defaults = inspect.getargspec(func)

    @wraps(func)
    def wrapper(self, *args, **kargs):
        for name, arg in list(zip(names[1:], args)) + list(kargs.items()):
            setattr(self, name, arg)

        for name, default in zip(reversed(names), reversed(defaults)):
            if not hasattr(self, name):
                setattr(self, name, default)

        func(self, *args, **kargs)

    return wrapper


class Batch:
    id = None
    nickname = None
    description = None
    priority = None
    expected_duration_time = None
    deadline = None
    repetition = None
    repetition_interval = None
    start_time = None
    execution_start_time = None
    execution_finish_time = None
    status = None
    owner = None
    owner_name = None
    rule = None
    enabled = None
    last_execution = None

    @initializer
    def __init__(self, id=None, nickname=None, description=None, priority=None, expected_duration_time=None, deadline=None, repetition=None, repetition_interval=None, start_time=None, execution_start_time=None, execution_finish_time=None, status=None, owner=None, owner_name=None, rule=None, enabled=None, last_execution=None):
        pass

    def get_url(self):
        return "%s/batch/" % SCHEDULER_URL


class Job:
    """
    A job determine what is gonna be executed and how. It stores the main
    informations about its execution.
    """
    id = None
    nickname = None
    description = None
    batch = None
    host = None
    docker_container_name = None
    command = None
    arguments = None
    status = None
    minimum_requirements = None
    expected_duration_time = None
    deadline = None
    execution_start_time = None
    execution_finish_time = None
    enabled = None
    run_as_user = None
    output = None
    output_err = None
    status_code = None

    @initializer
    def __init__(self, id=None, nickname=None, description=None, batch=None, host=None, docker_container_name=None,
    command=None, arguments=None, status=None, minimum_requirements=None, expected_duration_time=None,
    deadline=None, execution_start_time=None, execution_finish_time=None, enabled=None, run_as_user=None,
    output=None, output_err=None, status_code=None):
        pass

    def get_url(self):
        return "%s/job/" % SCHEDULER_URL


class JobDependency:
    id = None
    batch = None
    predecessor = None
    successor = None

    @initializer
    def __init__(self, id=None, batch=None, predecessor=None, successor=None):
        pass

    def get_url(self):
        return "%s/job_dependency/" % SCHEDULER_URL


class BatchGroup:
    id = None
    nickname = None
    description = None
    priority = None
    repetition = None
    repetition_interval = None
    start_time = None
    execution_start_time = None
    finish_time = None
    status = None
    owner = None
    owner_name = None
    enabled = None
    last_execution = None

    @initializer
    def __init__(self, id=None, nickname=None, description=None, priority=None,
     repetition=None, repetition_interval=None, start_time=None, execution_start_time=None,
     finish_time=None, status=None, owner=None, owner_name=None, enabled=None, last_execution=None):
        pass

    def get_url(self):
        return "%s/batch_group/" % SCHEDULER_URL


class BatchGroupExecutionOrder:
    id = None
    batch_group = None
    predecessor = None
    successor = None

    @initializer
    def __init__(self, id=None, batch_group=None, predecessor=None, successor=None):
        pass
    
    def get_url(self):
        return "%s/batch_group_execution_order/" % SCHEDULER_URL


class Resource:
    id = None
    name = None
    cpu = None
    memory = None
    disk = None

    @initializer
    def __init__(self, id=None, name=None, cpu=None, memory=None, disk=None):
        pass

    def get_url(self):
        return "%s/resource/" % SCHEDULER_URL


class Host:
    id = None
    hostname = None
    ip = None
    status = None
    cpu = None
    memory = None
    disk = None
    enabled = None

    @initializer
    def __init__(self, id=None, hostname=None, ip=None, status=None, cpu=None, memory=None, disk=None, enabled=None):
        pass

    def get_url(self):
        return "%s/host/" % SCHEDULER_URL
