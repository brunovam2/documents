from scheduler.scheduler import Batch
from datetime import datetime
from session import BKSession
import time


bb = Batch(id=1,nickname="teste", description="sdfjkasda", priority=1, expected_duration_time=None, deadline=None, repetition=99, repetition_interval=1, start_time=datetime.now(), execution_start_time=None, execution_finish_time=None, status=None, owner="brunovam@gmail.com", owner_name="Bruno Machado", rule=None, enabled=False, last_execution=None)

ss = BKSession("","","http://localhost:9030")
#bb = Batch()
aa = ss.get(bb)
b = Batch(**aa)
b.nickname="aaa"
ll = ss.post(b)
time.sleep(10)
b = Batch(**ll)
ss.delete(b)
#aa = ss.post(bb)
print(aa)
