import uuid
from django.db import models
from scheduler.models import Job, Batch
from eca.models import EventType, ExecutionStatus, ObjectType, Condition, Action


class BatchExecution(models.Model):
    """
    Stores the execution details of every Batch Execution.
    """
    uuid = models.UUIDField(primary_key=True, default=uuid.uuid4)
    batch = models.ForeignKey(Batch)
    start_time = models.DateTimeField() # programmed start time
    deadline = models.DateTimeField(null=True, blank=True)
    status = models.ForeignKey(ExecutionStatus)
    #achieved_deadline = models.BooleanField()
    execution_start_time = models.DateTimeField(null=True)
    execution_finish_time = models.DateTimeField(null=True)
    real_finish_time = models.DateTimeField(null=True) # Execution finish time + related new batches/jobs
    details = models.TextField(null=True)


class JobExecution(models.Model):
    """
    Stores the execution details of every Job Execution.
    """
    uuid = models.UUIDField(primary_key=True, default=uuid.uuid4)
    batch_execution = models.ForeignKey(BatchExecution)
    job = models.ForeignKey(Job)
    status = models.ForeignKey(ExecutionStatus)
    deadline = models.DateTimeField(null=True, blank=True)
    execution_start_time = models.DateTimeField(null=True)
    execution_finish_time = models.DateTimeField(null=True)
    real_finish_time = models.DateTimeField(null=True)
    output = models.TextField(null=True)
    output_err = models.TextField(null=True)
    exit_code = models.IntegerField(null=True)
    details = models.TextField(null=True)


class ConditionExecution(models.Model):
    """
    Stores the execution details of every Condition Execution.
    """
    uuid = models.UUIDField(primary_key=True, default=uuid.uuid4)
    batch_execution = models.ForeignKey(BatchExecution)
    condition = models.ForeignKey(Condition)
    execution_start_time = models.DateTimeField()
    execution_finish_time = models.DateTimeField(null=True)
    status = models.ForeignKey(ExecutionStatus)

class ActionExecution(models.Model):
    """
    Stores the execution details of every Action Execution.
    """
    uuid = models.UUIDField(primary_key=True, default=uuid.uuid4)
    batch_execution = models.ForeignKey(BatchExecution)
    action = models.ForeignKey(Action)
    execution_start_time = models.DateTimeField()
    execution_finish_time = models.DateTimeField(null=True)
    real_finish_time = models.DateTimeField(null=True)
    status = models.ForeignKey(ExecutionStatus)

# class EventClass(models.Model):
#     """
#     Specifies if event is a Batch or Job event
#     """
#     id = models.AutoField(primary_key=True)
#     name = models.CharField(max_length=30)

class RuleExecution(models.Model):
    """
    Stores the execution details of every Action Execution.
    """
    uuid = models.UUIDField(primary_key=True, default=uuid.uuid4)
    batch_execution = models.ForeignKey(BatchExecution)
    event_type = models.ForeignKey(EventType)
    event_id = models.IntegerField()
    rule_type = models.IntegerField()
    #COLOCAR RULE_TYPE ALTERAR SIGNALIZE PARA TESTAR TIPO DA INSTANCIA E ARMAZENAR SE É BATCH_RULE OU NAO
    #DEPOISOLHAR SE VAI SER MESMO NECESSARIO TER PONTEIROS PARA ACTION E EXECUTION. AHCO QUE PODE SER QUE PRECISE CASO UMA RULE SEJA ALTERADA PRA NAO PERDER INFORMACAO DE EXECUCAO
    #PRECISA COLOCAR RULE AQUI?? SE PODE SER MUDADA A QUALQUER MOMENTO??
    condition = models.ForeignKey(Condition)
    action = models.ForeignKey(Action)
    event_time = models.DateTimeField(null=True)
    condition_execution_start_time = models.DateTimeField(null=True)
    condition_execution_finish_time = models.DateTimeField(null=True)
    action_execution_start_time = models.DateTimeField(null=True)
    action_execution_finish_time = models.DateTimeField(null=True)
    action_real_finish_time = models.DateTimeField(null=True)
    status = models.ForeignKey(ExecutionStatus)

class EventLogExecution(models.Model):
    """
    Stores the execution details of every Event Execution.
    """
    uuid = models.UUIDField(primary_key=True, default=uuid.uuid4)
    event_type = models.ForeignKey(EventType)
    event_id = models.IntegerField()
    execution_start_time = models.DateTimeField()
    execution_finish_time = models.DateTimeField(null=True)
    key = models.TextField(null=True)
    value = models.TextField(null=True)
    batch_execution = models.ForeignKey(BatchExecution, null=True)

class TimelineExecution(models.Model):
    """
    Stores the execution details of every Batch/Job/Event/Condition/Action Execution in a timeline.
    This class has data stored in other tables. This is for performance improvement
    """
    uuid = models.UUIDField(primary_key=True, default=uuid.uuid4)
    batch_execution = models.ForeignKey(BatchExecution)
    obj_type = models.ForeignKey(ObjectType)
    obj_id = models.IntegerField()
    current_datetime = models.DateTimeField()
    execution_start_time = models.DateTimeField(null=True)
    execution_finish_time = models.DateTimeField(null=True)
    real_finish_time = models.DateTimeField(null=True)
    status = models.ForeignKey(ExecutionStatus, null=True)

class JobExecutionDetailsStatus(models.Model):
    """#TODO:COLOCAR ESTES DADOS PADRÃO NA TABELA ATRAVES DE UM DJANGO ADMIN CUSTOM COMMAND
    0 - No Agent info
    1 - Executing
    2 - Executed
    3 - Aborted
    """
    id = models.AutoField(primary_key=True)
    name = models.CharField(max_length=20)

class JobExecutionDetails(models.Model):
    """
    This class stores the agent/BKServer communication fields
    """
    id = models.AutoField(primary_key=True)
    job_execution = models.ForeignKey(JobExecution)
    job_pid = models.IntegerField(null=True) # Used to terminate an executing job if necessary
    agent_pid = models.IntegerField(null=True) # Used to kill the agents if necessary
    agent_port = models.IntegerField(null=True) # Agent connection port. BK uses it for sending commands like 'terminate job'
    status = models.ForeignKey(JobExecutionDetailsStatus)
