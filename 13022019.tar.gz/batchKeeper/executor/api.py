from datetime import datetime
from .models import BatchExecution, JobExecution, ConditionExecution, ActionExecution, JobExecutionDetails, EventLogExecution, TimelineExecution, JobExecutionDetailsStatus
from eca.models import ExecutionStatus, ObjectType

class Signalize(object):
    batch_status2execution_status = {0:"WILL_EXECUTE", 1:"WILL_EXECUTE", 2:"EXECUTING", 3:"SUCCESS", 4:"PARTIALLY_SUCCESS", 5:"FAILED"}

    @staticmethod
    def update_instance(instance, initial_data, kwargs):
        for dictionary in initial_data:
            for key in dictionary:
                setattr(instance, key, dictionary[key])
        for key in kwargs:
            setattr(instance, key, kwargs[key])
        instance.save()

    
    @staticmethod
    def batch_execution(batch_instance, uuid=None):
        """
        Creates or updates BatchExecution objects
        """
        if not uuid:
            instance = BatchExecution()
            # BatchExecution.objects.filter(batch=batch_instance,status__in=ExecutionStatus.objects.filter(name__in=["EXECUTING"]))
        else:
            instance = BatchExecution.objects.get(uuid=uuid)
        instance.batch = batch_instance
        instance.start_time = batch_instance.start_time
        instance.deadline = batch_instance.deadline
        instance.status = ExecutionStatus.objects.get(name=Signalize.batch_status2execution_status[batch_instance.status])
        instance.execution_start_time = batch_instance.execution_start_time
        instance.execution_finish_time = batch_instance.execution_finish_time
        instance.real_finish_time = batch_instance.execution_finish_time
        instance.save()

        timeline = TimelineExecution.objects.create(
                batch_execution=instance,
                obj_type=ObjectType.objects.get(name="BATCH"),
                obj_id=instance.batch.id,
                current_datetime=datetime.now(),
                execution_start_time=instance.execution_start_time,
                execution_finish_time=instance.execution_finish_time,
                real_finish_time=instance.execution_finish_time,
                status=instance.status
            )
        
        return instance
    
    # @staticmethod
    # def batch_execution(*initial_data, **kwargs):
    #     """
    #     Creates or updates BatchExecution objects

    #     """
    #     if not "batch" in initial_data[0] and not "uuid" in initial_data[0]:
    #         #Throw BatchExecutionNotFound exception
    #         return False
    #     if "batch" in initial_data[0]:
    #         batch_instance = initial_data[0]['batch']
    #         if not isinstance(batch_instance, Batch):
    #             #Throw BatchNotFound exception
    #             return False
    #     if "uuid" in initial_data[0]:
    #         uuid = initial_data[0]['uuid']
    #         instance = BatchExecution.objects.get(uuid=uuid)
    #     else:
    #         instance = BatchExecution()

    #     Signalize.update_instance(instance, initial_data, kwargs)
    #     timeline = TimelineExecution.objects.create(
    #             batch_execution=instance,
    #             obj_type=ObjectType.objects.get(name="batch"),
    #             obj_id=instance.batch.id,
    #             current_datetime=datetime.now(),
    #             execution_start_time=instance.execution_start_time,
    #             execution_finish_time=instance.execution_finish_time,
    #             real_finish_time=instance.real_finish_time,
    #             status=instance.status
    #         )
    #     return instance
    
    # @staticmethod
    # def job_execution(*initial_data, **kwargs):
    #     if not "batch_execution" in initial_data[0] and not "job" in initial_data[0] and not "uuid" in initial_data[0]:
    #         #Throw BatchExecutionNotFound exception
    #         return False
    #     if "job" in initial_data[0]:
    #         job_instance = initial_data[0]['batch']
    #         if not isinstance(job_instance, Job):
    #             #Throw BatchNotFound exception
    #             return False
    #     if "batch_execution" in initial_data[0]:
    #         batch_execution_instance = initial_data[0]['batch_execution']
    #         if not isinstance(batch_execution_instance, BatchExecution):
    #             #Throw BatchExecutionNotFound exception
    #             return False
    #     if "uuid" in initial_data[0]:
    #         uuid = initial_data[0]['uuid']
    #         instance = JobExecution.objects.get(uuid=uuid)
    #     else:
    #         if not "batch_execution" in initial_data[0]:
    #             #Throw BatchExecutionInstanceMissing
    #             return False
    #         instance = JobExecution()
    #         JobExecutionDetails.create(job_execution=instance)

    #     Signalize.update_instance(instance, initial_data, kwargs)
    #     timeline = TimelineExecution.objects.create(
    #             batch_execution=instance.batch_execution,
    #             obj_type=ObjectType.objects.get(name="job"),
    #             obj_id=instance.job.id,
    #             current_datetime=datetime.now(),
    #             execution_start_time=instance.execution_start_time,
    #             execution_finish_time=instance.execution_finish_time,
    #             real_finish_time=instance.real_finish_time,
    #             status=instance.status
    #         )
    #     return instance

    @staticmethod
    def job_execution(job_instance, batch_execution, uuid=None):
        """
        Creates or updates JobExecution objects
        """
        if not uuid:
            instance = JobExecution()
            instance.batch_execution = batch_execution
        else:
            instance = JobExecution.objects.get(uuid=uuid)
        instance.job = job_instance
        instance.status = ExecutionStatus.objects.get(name=Signalize.batch_status2execution_status[job_instance.status])
        instance.deadline = job_instance.deadline
        instance.execution_start_time = job_instance.execution_start_time
        instance.execution_finish_time = job_instance.execution_finish_time
        instance.real_finish_time = job_instance.execution_finish_time
        instance.output = job_instance.output
        instance.output_err = job_instance.output_err
        instance.exit_code = job_instance.status_code
        instance.save()

        timeline = TimelineExecution.objects.create(
                batch_execution=instance.batch_execution,
                obj_type=ObjectType.objects.get(name="JOB"),
                obj_id=instance.job.id,
                current_datetime=datetime.now(),
                execution_start_time=instance.execution_start_time,
                execution_finish_time=instance.execution_finish_time,
                real_finish_time=instance.real_finish_time,
                status=instance.status
            )
        if not uuid:
            j_details = JobExecutionDetails()
            j_details.job_execution = instance
            j_details.status = JobExecutionDetailsStatus.objects.get(name="NO_AGENT_INFO")
            j_details.save()
        
        return instance

    @staticmethod
    def rule_execution(rule_instance, batch_execution, uuid=None):
        """
        Creates or updates JobExecution objects
        """
        if not uuid:
            instance = RuleExecution()
            instance.batch_execution = batch_execution
        else:
            instance = RuleExecution.objects.get(uuid=uuid)
        
        if isinstance(BatchRule, rule_instance):
            instance.rule_type = 0
            rule_name = "BATCH_RULE"

        else:
            instance.rule_type = 1
            rule_name = "JOB_RULE"
        instance.event_type = rule_instance.event.e_type
        instance.event_id = rule_instance.event.id
        instance.condition = rule_instance.condition
        instance.action = rule_instance.action
        instance.save()

        timeline = TimelineExecution.objects.create(
                batch_execution=instance,
                obj_type=ObjectType.objects.get(name=rule_name),
                obj_id=instance.id,
                current_datetime=datetime.now(),
                execution_start_time=instance.condition_execution_start_time,
                execution_finish_time=instance.action_execution_finish_time,
                real_finish_time=instance.action_real_finish_time,
                status=instance.status
            )
        
        return instance
    
#     @staticmethod
#     def condition_execution(job_instance, batch_execution, uuid=None):
#         instance = ConditionExecution()
#         uuid = initial_data[0]['uuid']
#         if uuid:
#             instance = ConditionExecution.objects.get(uuid=uuid)
#         Signalize.update_instance(instance, initial_data, kwargs)
#         timeline = TimelineExecution.objects.create(
#                 batch_execution=instance.batch_execution,
#                 obj_type=ObjectType.objects.get(name="condition"),
#                 obj_id=instance.condition.id,
#                 current_datetime=datetime.now(),
#                 execution_start_time=instance.execution_start_time,
#                 execution_finish_time=instance.execution_finish_time,
#                 real_finish_time=instance.execution_finish_time,
#                 status=instance.status
#             )
#         return instance

#     #TODO:Colocar ECAExecution depois talvez ou indicar a execução de um ECA na Timeline
#     @staticmethod
#     def condition_execution(condition_instance, batch_execution, uuid=None):
#         """
#         Creates or updates JobExecution objects
#         """
#         if not uuid:
#             instance = ConditionExecution()
#             instance.batch_execution = batch_execution
#         else:
#             instance = ConditionExecution.objects.get(uuid=uuid)
#         instance.condition = condition_instance
#         instance.execution_start_time = job_instance.execution_start_time
#         instance.execution_finish_time = job_instance.execution_finish_time
#         instance.status = job_instance.status
# l        instance.save()

#     @staticmethod
#     def action_execution(*initial_data, **kwargs):
#         instance = ActionExecution()
#         uuid = initial_data[0]['uuid']
#         if uuid:
#             instance = ActionExecution.objects.get(uuid=uuid)
#         Signalize.update_instance(instance, initial_data, kwargs)
#         timeline = TimelineExecution.objects.create(
#                 batch_execution=instance.batch_execution,
#                 obj_type=ObjectType.objects.get(name="action"),
#                 obj_id=instance.action.id,
#                 current_datetime=datetime.now(),
#                 execution_start_time=instance.execution_start_time,
#                 execution_finish_time=instance.execution_finish_time,
#                 real_finish_time=instance.execution_real_time,
#                 status=instance.status
#             )
#         return instance



    @staticmethod
    def event_log_execution(eventlog_instance, batch_execution, uuid=None):
        """
        Creates or updates JobExecution objects
        """
        if not uuid:
            instance = RuleExecution()
            instance.batch_execution = batch_execution
        else:
            instance = RuleExecution.objects.get(uuid=uuid)
        
        if isinstance(BatchRule, rule_instance):
            instance.rule_type = 0
            rule_name = "BATCH_RULE"

        else:
            instance.rule_type = 1
            rule_name = "JOB_RULE"
        instance.event_type = rule_instance.event.e_type
        instance.event_id = rule_instance.event.id
        instance.condition = rule_instance.condition
        instance.action = rule_instance.action
        instance.save()

        timeline = TimelineExecution.objects.create(
                batch_execution=instance,
                obj_type=ObjectType.objects.get(name=rule_name),
                obj_id=instance.id,
                current_datetime=datetime.now(),
                execution_start_time=instance.condition_execution_start_time,
                execution_finish_time=instance.action_execution_finish_time,
                real_finish_time=instance.action_real_finish_time,
                status=instance.status
            )
        
        return instance

    # @staticmethod
    # def TimelineExecution(*initial_data, **kwargs):
    #     instance = TimelineExecution()
    #     uuid = initial_data[0]['uuid']
    #     if uuid:
    #         instance = TimelineExecution.objects.get(uuid=uuid)
    #     Signalize.update_instance(instance, initial_data, kwargs)
    #     return instance

    # @staticmethod
    # def JobExecutionDetails(*initial_data, **kwargs):
    #     instance = JobExecutionDetails()
    #     uuid = initial_data[0]['uuid']
    #     if uuid:
    #         instance = JobExecutionDetails.objects.get(uuid=uuid)
    #     Signalize.update_instance(instance, initial_data, kwargs)
    #     return instance
