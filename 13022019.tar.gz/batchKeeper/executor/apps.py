from django.apps import AppConfig


class ExecutorConfig(AppConfig):
    name = 'executor'
