from django.conf.urls import url, include

from . import views


urlpatterns = [
    url(r'^execution_configs$', views.execution_configs, name='execution_configs'),
    url(r'^execution_result$', views.execution_result, name='execution_result'),
]
