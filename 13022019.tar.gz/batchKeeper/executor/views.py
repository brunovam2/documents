from django.shortcuts import render
from django.views.decorators.csrf import csrf_exempt
import json
from datetime import datetime
from django.http import HttpResponse
from scheduler.models import BatchStatus, JobStatus
from .models import BatchExecution, JobExecution, JobExecutionDetails, JobExecutionDetailsStatus
from .api import Signalize


@csrf_exempt
def execution_configs(request):
    configs = json.loads(request.body)
    job_execution_details = JobExecutionDetails.objects.get(job_execution__uuid=configs["job_execution_uuid"])
    job_execution_details.agent_pid = configs["agent_pid"]
    job_execution_details.agent_port = configs["agent_port"]
    job_execution_details.status = JobExecutionDetailsStatus.objects.get(name="EXECUTING")
    job_execution_details.save()
    return HttpResponse("",status=200)

@csrf_exempt
def execution_result(request):
    result = json.loads(request.body)
    job_execution_details = JobExecutionDetails.objects.get(job_execution__uuid=result["job_execution_uuid"])
    job = job_execution_details.job_execution.job
    job.output = result["output"]
    job.output_err = result["output_err"]
    job.status_code = int(result["exit_code"])
    job.finish_time = datetime.now()
    job.save()

    batch_execution = job_execution_details.job_execution.batch_execution
    Signalize.job_execution(job_instance=job, batch_execution=batch_execution, uuid=result["job_execution_uuid"])

    if job.status_code != 0:
        job.status = JobStatus.FAILED
    else:
        job.status = JobStatus.EXECUTED
    job.save(update_fields=['status'])
    Signalize.job_execution(job_instance=job, batch_execution=batch_execution, uuid=result["job_execution_uuid"])

    job_execution_details.job_pid = result["job_pid"]
    job_execution_details.status = JobExecutionDetailsStatus.objects.get(name="EXECUTED")
    job_execution_details.save()
    return HttpResponse("",status=200)