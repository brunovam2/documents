curl -H 'Accept: application/json; indent=4' -u brunovam:Fibracell* http://127.0.0.1:10001/scheduler/v1/users/
