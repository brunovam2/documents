from django.apps import AppConfig


class LogTaskMonitoringConfig(AppConfig):
    name = 'log_task_monitoring'
