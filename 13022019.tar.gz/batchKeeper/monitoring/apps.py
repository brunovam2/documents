from django.apps import AppConfig


class MonitoringConfig(AppConfig):
    name = 'monitoring'
