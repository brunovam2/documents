from django.conf.urls import url, include

from . import views
from rest_framework import routers
from . import rest_views


router = routers.DefaultRouter()
router.register(r'users', rest_views.UserViewSet)
router.register(r'groups', rest_views.GroupViewSet)
router.register(r'batch', rest_views.BatchViewSet)
router.register(r'batch_group', rest_views.BatchGroupViewSet)
router.register(r'batch_group_execution_order', rest_views.BatchGroupExecutionOrderViewSet)
router.register(r'job', rest_views.JobViewSet)
router.register(r'job_dependency', rest_views.JobDependencyViewSet)
router.register(r'resource', rest_views.ResourceViewSet)
router.register(r'host', rest_views.HostViewSet)


urlpatterns = [
    url(r'^$', views.index, name='index'),
    url(r'v1/', include(router.urls)),
    url(r'^api-auth/', include('rest_framework.urls', namespace='rest_framework'))
]
