from django.contrib.auth.models import User, Group
from rest_framework import serializers
from .models import Batch, BatchGroup, BatchGroupExecutionOrder, Job, JobDependency, BatchStatus, JobStatus, Resource, Host


class UserSerializer(serializers.ModelSerializer):
    class Meta:
        model = User
        fields = ('url', 'username', 'email', 'groups')

    def create(self, validated_data):
        return User.objects.create(**validated_data)

    def update(self, instance, validated_data):
        instance.url = validated_data.get('url', instance.url)
        instance.username = validated_data.get('username', instance.username)
        instance.email = validated_data.get('email', instance.email)
        instance.groups = validated_data.get('groups', instance.groups)

        instance.save()
        return instance


class GroupSerializer(serializers.ModelSerializer):
    class Meta:
        model = Group
        fields = ('url', 'name')

    def create(self, validated_data):
        return User.objects.create(**validated_data)

    def update(self, instance, validated_data):
        instance.url = validated_data.get('url', instance.url)
        instance.name = validated_data.get('name', instance.name)

        instance.save()
        return instance


class BatchSerializer(serializers.ModelSerializer):
    class Meta:
        model = Batch
        fields = ('id','nickname', 'description', 'expected_duration_time',
         'deadline', 'repetition', 'repetition_interval',# 'timezone',
          'start_time', 'execution_start_time', 'execution_finish_time','status',
          'owner','owner_name','rule','enabled',
          'last_execution')

    def create(self, validated_data):
        return Batch.objects.create(**validated_data)

    def update(self, instance, validated_data):
        instance.id = validated_data.get('id', instance.id)
        instance.nickname = validated_data.get('nickname', instance.nickname)
        instance.description = validated_data.get('description', instance.description)
        instance.expected_duration_time = validated_data.get('expected_duration_time', instance.expected_duration_time)
        instance.deadline = validated_data.get('deadline', instance.deadline)
        instance.repetition = validated_data.get('repetition', instance.repetition)
        instance.repetition_interval = validated_data.get('repetition_interval', instance.repetition_interval)
        #instance.timezone = validated_data.get('timezone', instance.timezone)
        instance.start_time = validated_data.get('start_time', instance.start_time)
        instance.execution_start_time = validated_data.get('execution_start_time', instance.execution_start_time)
        instance.execution_finish_time = validated_data.get('execution_finish_time', instance.execution_finish_time)
        instance.status = validated_data.get('status', instance.status)
        instance.owner = validated_data.get('owner', instance.owner)
        instance.owner_name = validated_data.get('owner_name', instance.owner_name)
        instance.rule = validated_data.get('rule', instance.rule)
        instance.enabled = validated_data.get('enabled', instance.enabled)
        instance.last_execution = validated_data.get('last_execution', instance.last_execution)
        instance.save()
        return instance


class BatchGroupSerializer(serializers.ModelSerializer):
    class Meta:
        model = BatchGroup
        fields = ('id','nickname', 'description', 'priority', 'repetition', 'repetition_interval',# 'timezone',
          'start_time', 'execution_start_time', 'execution_finish_time','status',
          'owner','owner_name','enabled',
          'last_execution')

    def create(self, validated_data):
        return BatchGroup.objects.create(**validated_data)

    def update(self, instance, validated_data):
        instance.id = validated_data.get('id', instance.id)
        instance.nickname = validated_data.get('nickname', instance.nickname)
        instance.description = validated_data.get('description', instance.description)
        instance.priority = validated_data.get('priority', instance.priority)
        instance.repetition = validated_data.get('repetition', instance.repetition)
        instance.repetition_interval = validated_data.get('repetition_interval', instance.repetition_interval)
        #instance.timezone = validated_data.get('timezone', instance.timezone)
        instance.start_time = validated_data.get('start_time', instance.start_time)
        instance.execution_start_time = validated_data.get('execution_start_time', instance.execution_start_time)
        instance.execution_finish_time = validated_data.get('execution_finish_time', instance.execution_finish_time)
        instance.status = validated_data.get('status', instance.status)
        instance.owner = validated_data.get('owner', instance.owner)
        instance.owner_name = validated_data.get('owner_name', instance.owner_name)
        instance.enabled = validated_data.get('enabled', instance.enabled)
        instance.last_execution = validated_data.get('last_execution', instance.last_execution)
        instance.save()
        return instance


class BatchGroupExecutionOrderSerializer(serializers.ModelSerializer):
    class Meta:
        model = BatchGroupExecutionOrder
        fields = ('id','batch_group', 'predecessor', 'successor')

    def create(self, validated_data):
        return BatchGroupExecutionOrder.objects.create(**validated_data)

    def update(self, instance, validated_data):
        instance.id = validated_data.get('id', instance.id)
        instance.batch_group = validated_data.get('batch_group', instance.batch_group)
        instance.predecessor = validated_data.get('predecessor', instance.predecessor)
        instance.successor = validated_data.get('successor', instance.successor)
        instance.save()
        return instance


class JobDependencySerializer(serializers.ModelSerializer):
    class Meta:
        model = JobDependency
        fields = ('id','batch', 'predecessor', 'successor')

    def create(self, validated_data):
        return JobDependency.objects.create(**validated_data)

    def update(self, instance, validated_data):
        instance.id = validated_data.get('id', instance.id)
        instance.batch = validated_data.get('batch', instance.batch)
        instance.predecessor = validated_data.get('predecessor', instance.predecessor)
        instance.successor = validated_data.get('successor', instance.successor)
        instance.save()
        return instance


class JobSerializer(serializers.ModelSerializer):
    class Meta:
        model = Job
        fields = ('id','nickname','description','batch','host',
        'docker_container_name','command','arguments','status',
        'minimum_requirements','expected_duration_time','deadline',
        'start_time','execution_finish_time','enabled','run_as_user','output','output_err',
        'status_code')

        def create(self, validated_data):
            return Job.objects.create(**validated_data)

        def update(self, instance, validated_data):
            instance.id = validated_data.get('id', instance.id)
            instance.nickname = validated_data.get('nickname', instance.nickname)
            instance.description = validated_data.get('description', instance.description)
            instance.task = validated_data.get('batch', instance.task)
            instance.host = validated_data.get('host', instance.host)
            instance.docker_container_name = validated_data.get('docker_container_name', instance.docker_container_name)
            instance.command = validated_data.get('command', instance.command)
            instance.arguments = validated_data.get('arguments', instance.arguments)
            instance.status = validated_data.get('status', instance.status)
            instance.minimum_requirements = validated_data.get('minimum_requirements', instance.minimum_requirements)
            instance.expected_duration_time = validated_data.get('expected_duration_time', instance.expected_duration_time)
            instance.deadline = validated_data.get('deadline', instance.deadline)
            instance.start_time = validated_data.get('start_time', instance.start_time)
            instance.execution_finish_time = validated_data.get('execution_finish_time', instance.execution_finish_time)
            instance.enabled = validated_data.get('enabled', instance.enabled)
            instance.run_as_user = validated_data.get('run_as_user', instance.run_as_user)
            instance.output = validated_data.get('output', instance.output)
            instance.output_err = validated_data.get('output_err', instance.output_err)
            instance.status_code = validated_data.get('status_code', instance.status_code)

            instance.save()
            return instance


class ResourceSerializer(serializers.ModelSerializer):
    class Meta:
        model = Resource
        fields = ('id', 'name', 'cpu', 'memory', 'disk')

    def create(self, validated_data):
        return Resource.objects.create(**validated_data)

    def update(self, instance, validated_data):
        instance.id = validated_data.get('id', instance.id)
        instance.name = validated_data.get('name', instance.name)
        instance.cpu = validated_data.get('cpu', instance.cpu)
        instance.memory = validated_data.get('memory', instance.memory)
        instance.disk = validated_data.get('disk', instance.disk)

        instance.save()
        return instance


class HostSerializer(serializers.ModelSerializer):
    class Meta:
        model = Host
        fields = ('id', 'hostname', 'ip', 'status', 'cpu', 'memory', 'disk')

    def create(self, validated_data):
        return Host.objects.create(**validated_data)

    def update(self, instance, validated_data):
        instance.id = validated_data.get('id', instance.id)
        instance.hostname = validated_data.get('hostname', instance.hostname)
        instance.ip = validated_data.get('ip', instance.ip)
        instance.status = validated_data.get('status', instance.status)
        instance.cpu = validated_data.get('cpu', instance.cpu)
        instance.memory = validated_data.get('memory', instance.memory)
        instance.disk = validated_data.get('disk', instance.disk)

        instance.save()
        return instance
