# -*- coding: utf-8 -*-
from __future__ import unicode_literals
from django.db import models
import inspect
from django.db.models.signals import pre_save
from django.dispatch import receiver


class Event:
    """
    This class represent generical workflow events. It is used to implement the
    ECA mechanism. 
    """
    job_status_code = 0
    batch_status_change = 1
    job_status_change = 2
    batch_duration = 3
    job_duration = 4
    batch_max_finish_time = 5
    job_max_finish_time = 6

    @staticmethod
    def get_name(id):
        events = ["job_status_code",
            "batch_status_change",
            "job_status_change",
            "batch_duration",
            "job_duration",
            "batch_max_finish_time",
            "job_max_finish_time"]

        return events[id]

    @staticmethod
    def get_tuple():
        attributes = inspect.getmembers(Event, lambda a: not (inspect.isroutine(a)))
        choices = tuple([a[::-1] for a in attributes if not (a[0].startswith('__') and a[0].endswith('__'))])
        return choices


class JobStatus(object):
    QUEUED = 0
    EXECUTING = 1
    EXECUTED = 2
    FAILED = 3

    @staticmethod
    def get_name(id):
        status = ["QUEUED",
        "EXECUTING",
        "EXECUTED",
        "FAILED"]

        return status[id]

    @staticmethod
    def get_tuple():
        attributes = inspect.getmembers(JobStatus, lambda a: not (inspect.isroutine(a)))
        choices = tuple([a[::-1] for a in attributes if not (a[0].startswith('__') and a[0].endswith('__'))])
        return choices


class BatchStatus(object):
    WAITING =0
    QUEUED = 1
    EXECUTING = 2
    SUCCESS = 3
    PARTIALLY_SUCCESS = 4
    FAILED = 5

    @staticmethod
    def get_name(id):
        status = ["WAITING",
        "QUEUED",
        "EXECUTING",
        "SUCCESS",
        "PARTIALLY_SUCCESS",
        "FAILED"]

        return status[id]

    @staticmethod
    def get_tuple():
        attributes = inspect.getmembers(BatchStatus, lambda a: not (inspect.isroutine(a)))
        choices = tuple([a[::-1] for a in attributes if not (a[0].startswith('__') and a[0].endswith('__'))])
        return choices


class HostStatus(object):
    DISCONECTED = 0
    RUNNING = 1

    @staticmethod
    def get_tuple():
        attributes = inspect.getmembers(HostStatus, lambda a: not (inspect.isroutine(a)))
        choices = tuple([a[::-1] for a in attributes if not (a[0].startswith('__') and a[0].endswith('__'))])
        return choices


class Host(models.Model):
    """
    Represents a machine that can be used to process jobs.
    """
    id = models.AutoField(primary_key=True)
    hostname = models.CharField(max_length=60, unique=True)
    ip = models.GenericIPAddressField()
    status = models.IntegerField(default=HostStatus.RUNNING, choices=HostStatus().get_tuple())
    cpu = models.DecimalField(decimal_places=2, max_digits=15)
    memory = models.DecimalField(decimal_places=2, max_digits=15)
    disk = models.DecimalField(decimal_places=2, max_digits=15)#In MB
    enabled = models.BooleanField(default=True)
    # history = HistoricalRecords()

    def __str__(self):
        return self.hostname


class Resource(models.Model):
    id = models.AutoField(primary_key=True)
    name = models.CharField(max_length=30)
    cpu = models.DecimalField(decimal_places=2, max_digits=15)
    memory = models.DecimalField(decimal_places=2, max_digits=15)
    disk = models.DecimalField(decimal_places=2, max_digits=15)#In MB
    # history = HistoricalRecords()

    def __str__(self):
        return self.name


class Repetition(object):
    YEARLY = 10
    MONTHLY = 20
    WEEKLY = 30
    DAILY = 40
    HOURLY  = 50
    ONE_TIME = 99

    @staticmethod
    def get_tuple():
        attributes = inspect.getmembers(Repetition, lambda a: not(inspect.isroutine(a)))
        choices = tuple([a[::-1] for a in attributes if not(a[0].startswith('__') and a[0].endswith('__'))])
        return choices


class Batch(models.Model):
    """
    Each batch has at least one job to execute the processing commands
    """
    id = models.AutoField(primary_key=True)
    nickname = models.CharField(max_length=90)
    description = models.TextField(null=True)
    priority = models.IntegerField(default=1)
    expected_duration_time = models.TimeField(null=True, blank=True)
    deadline = models.DateTimeField(null=True, blank=True)
    repetition = models.IntegerField(
        choices=Repetition().get_tuple()
        )
    repetition_interval = models.IntegerField(default=1)
    # timezone = TimeZoneField(default='America/Sao_Paulo')
    start_time = models.DateTimeField()
    execution_start_time = models.DateTimeField(null=True, blank=True)
    execution_finish_time = models.DateTimeField(null=True, blank=True)
    status = models.IntegerField(default=0, choices=BatchStatus().get_tuple())
    owner = models.EmailField()
    owner_name = models.CharField(max_length=50)
    rule = models.BooleanField(default=False, blank=True)
    enabled = models.BooleanField(default=True)
    last_execution = models.DateTimeField(null=True)
    # history = HistoricalRecords()

    def __str__(self):
        return self.nickname

    class Meta:
        verbose_name_plural = "batches"


class Job(models.Model):
    """
    A job determine what is gonna be executed and how. It stores the main
    informations about its execution.
    """
    id = models.AutoField(primary_key=True)
    nickname = models.CharField(max_length=90)
    description = models.TextField(null=True)
    batch = models.ForeignKey(Batch, on_delete=models.CASCADE)
    host = models.ForeignKey(Host, on_delete=models.PROTECT, null=True)
    docker_container_name = models.CharField(max_length=50, null=True, blank=True)
    command = models.CharField(max_length=256)
    arguments = models.CharField(max_length=256, null=True)
    status = models.IntegerField(default=0, choices=JobStatus().get_tuple())
    minimum_requirements = models.ForeignKey(Resource, on_delete=models.CASCADE, default=1)
    expected_duration_time = models.TimeField(null=True, blank=True)
    deadline = models.DateTimeField(null=True, blank=True)
    execution_start_time = models.DateTimeField(null=True, blank=True)
    execution_finish_time = models.DateTimeField(null=True, blank=True)
    enabled = models.BooleanField(default=True)

    run_as_user = models.CharField(max_length=30, null=True, blank=True)
    output = models.TextField(null=True)
    output_err = models.TextField(null=True)
    status_code = models.IntegerField(null=True)
    # history = HistoricalRecords()

    def __str__(self):
        return self.nickname


class JobDependency(models.Model):
    id = models.AutoField(primary_key=True)
    batch = models.ForeignKey(Batch)
    predecessor = models.ForeignKey(Job, related_name="predecessor_job")
    successor = models.ForeignKey(Job, related_name="successor_job")

    class Meta:
        verbose_name_plural = "Job dependencies"


@receiver(pre_save, sender=JobDependency)
def pre_save_handler(sender, instance, *args, **kwargs):
    # TODO: Test if it is a DAG or not
    if instance.batch.id != instance.predecessor.batch.id or instance.batch.id != instance.successor.batch.id:
        raise Exception('Os jobs devem pertencer ao mesmo batch cadastrado')


class BatchGroup(models.Model):
    id = models.AutoField(primary_key=True)
    nickname = models.CharField(max_length=90)
    description = models.TextField(null=True)
    priority = models.IntegerField(default=1)
    repetition = models.IntegerField(
        choices=Repetition().get_tuple()
    )
    repetition_interval = models.IntegerField(default=1)
    # timezone = TimeZoneField(default='America/Sao_Paulo')
    start_time = models.DateTimeField()
    execution_start_time = models.DateTimeField(null=True)
    execution_finish_time = models.DateTimeField(null=True)
    status = models.IntegerField(default=0, choices=BatchStatus().get_tuple())
    owner = models.EmailField()
    owner_name = models.CharField(max_length=50)
    enabled = models.BooleanField(default=True)
    last_execution = models.DateTimeField(null=True)


class BatchGroupExecutionOrder(models.Model):
    id = models.AutoField(primary_key=True)
    batch_group = models.ForeignKey(BatchGroup)
    predecessor = models.ForeignKey(Batch, related_name="predecessor_batch")
    successor = models.ForeignKey(Batch, related_name="successor_batch")

