from datetime import datetime
from django.contrib.auth.models import User, Group
from django.core.exceptions import ObjectDoesNotExist
from rest_framework import viewsets
from .serializers import UserSerializer, GroupSerializer, BatchSerializer, BatchGroupSerializer, BatchGroupExecutionOrderSerializer, JobSerializer, JobDependencySerializer, ResourceSerializer, HostSerializer
from .models import Batch, Job, BatchStatus, JobStatus, Resource, Host, HostStatus, BatchGroup, BatchGroupExecutionOrder, JobDependency
from rest_framework.decorators import detail_route, list_route
from rest_framework.response import Response
from rest_framework import status
from rest_framework.views import APIView
import json
import socket
from rest_framework.views import APIView
from eca.rule_admin import RuleAdmin


class UserViewSet(viewsets.ModelViewSet):
    """
    API endpoint that allows users to be viewed or edited.
    """
    queryset = User.objects.all().order_by('-date_joined')
    serializer_class = UserSerializer


class GroupViewSet(viewsets.ModelViewSet):
    """
    API endpoint that allows groups to be viewed or edited.
    """
    queryset = Group.objects.all()
    serializer_class = GroupSerializer


class BatchViewSet(viewsets.ModelViewSet):
    """
    API endpoint that allows tasks to be viewed or edited.
    """
    queryset = Batch.objects.all()
    serializer_class = BatchSerializer


class BatchGroupViewSet(viewsets.ModelViewSet):
    """
    API endpoint that allows tasks to be viewed or edited.
    """
    queryset = BatchGroup.objects.all()
    serializer_class = BatchGroupSerializer


class BatchGroupExecutionOrderViewSet(viewsets.ModelViewSet):
    """
    API endpoint that allows tasks to be viewed or edited.
    """
    queryset = BatchGroupExecutionOrder.objects.all()
    serializer_class = BatchGroupExecutionOrderSerializer


class JobDependencyViewSet(viewsets.ModelViewSet):
    """
    API endpoint that allows tasks to be viewed or edited.
    """
    queryset = JobDependency.objects.all()
    serializer_class = JobDependencySerializer


class JobViewSet(viewsets.ModelViewSet):
    """
    API endpoint that allows jobs to be viewed or edited.
    """
    queryset = Job.objects.all()
    serializer_class = JobSerializer


class ResourceViewSet(viewsets.ModelViewSet):
    """
    API endpoint that allows resources to be viewed or edited.
    """
    queryset = Resource.objects.all()
    serializer_class = ResourceSerializer


class HostViewSet(viewsets.ModelViewSet):
    """
    API endpoint that allows hosts to be viewed or edited.
    """
    queryset = Host.objects.all()
    serializer_class = HostSerializer
