import time
from datetime import datetime, timedelta
from django.core.management.base import BaseCommand, CommandError
from scheduler.models import Executor, ExecutorStatus
import pytz


class Command(BaseCommand):
    help = 'Sends alive signals to the Scheduler'

    def add_arguments(self, parser):
        pass

    def handle(self, *args, **options):
        while True:
            executors = Executor.objects.all()
            for ex in executors:
                if ex.last_update < datetime.now(pytz.utc) - timedelta(0,60):
                    ex.status = ExecutorStatus.DISCONECTED
                    ex.save()
            time.sleep(60)
        self.stdout.write(self.style.SUCCESS('Successfully registered on Scheduler'))
