from uuid import uuid4


class Vertex():
    id = None
    name = None
    degree = None

    def __init__(self, id=None, name=None):
        self.id = id
        if not self.id:
            self.id = str(uuid4())
        self.name = name
        self.degree = 0

    def increment_degree(self):
        self.degree += 1

    def decrement_degree(self):
        self.degree -= 1
