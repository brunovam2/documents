#!/usr/bin/python
# -*- coding: utf-8 -*-
import copy


class Graph():
    VERTEX = None
    EDGE = None
    DEGREE = None

    def __init__(self):
        self.VERTEX = {}
        self.EDGE = {}
        self.DEGREE = {}

    def add_vertex(self, vertice):
        if not vertice.id in self.VERTEX:
            self.VERTEX[vertice.id] = vertice
            self.EDGE[vertice.id] = []
            if not vertice.degree in self.DEGREE:
                self.DEGREE[vertice.degree] = []
            self.DEGREE[vertice.degree].append(vertice.id)

    def del_vertex(self, vertice):
        if vertice.id in self.VERTEX:
            vizinhos = copy.deepcopy(self.EDGE[vertice.id])
            for a_id in vizinhos:
                self.del_edge(vertice, self.VERTEX[a_id])
            # if not self.EDGE[vertice.id]:
            #     self.EDGE.pop(vertice.id)
            self.VERTEX.pop(vertice.id)
            self.DEGREE[vertice.degree].remove(vertice.id)

    def add_edge(self, v1, v2, directed=True):
        if not v1.id in self.EDGE:
            self.EDGE[v1.id] = []
        if not v2.id in self.EDGE:
            self.EDGE[v2.id] = []
        self.EDGE[v1.id].append(v2.id)
        if not directed:
            self.EDGE[v2.id].append(v1.id)

        if v1.degree not in self.DEGREE:
            self.DEGREE[v1.degree] = []
        if v2.degree not in self.DEGREE:
            self.DEGREE[v2.degree] = []
        if not directed:
            if v1.degree + 1 not in self.DEGREE:
                self.DEGREE[v1.degree + 1] = []
        if v2.degree + 1 not in self.DEGREE:
            self.DEGREE[v2.degree + 1] = []

        if not directed:
            self.DEGREE[v1.degree].remove(v1.id)
            #v1.increment_degree()
            v1.increment_degree()
            self.DEGREE[v1.degree].append(v1.id)
        self.DEGREE[v2.degree].remove(v2.id)
        v2.increment_degree()
        self.DEGREE[v2.degree].append(v2.id)

    def del_edge(self, v1, v2, directed=True):
        self.EDGE[v1.id].remove(v2.id)
        self.DEGREE[v2.degree].remove(v2.id)
        v2.decrement_degree()
        self.DEGREE[v2.degree].append(v2.id)
        if not directed:
            self.EDGE[v2.id].remove(v1.id)
            self.DEGREE[v1.degree].remove(v1.id)
            v1.decrement_degree()
            self.DEGREE[v1.degree].append(v1.id)

    # A recursive function used by topologicalSort
    def topological_sort_util(self, v_id, visited, stack):

        # Mark the current node as visited.
        visited[v_id] = True

        # Recur for all the vertices adjacent to this vertex
        for u_id in self.EDGE[v_id]:
            if not visited[u_id]:
                self.topological_sort_util(u_id, visited, stack)

        # Push current vertex to stack which stores result
        stack.insert(0, v_id)

    # The function to do Topological Sort. It uses recursive
    # topologicalSortUtil()
    def topological_sort(self):
        # Mark all the vertices as not visited
        visited = {}
        for vertex_id in self.VERTEX:
            visited[vertex_id] = False
        stack = []

        # Call the recursive helper function to store Topological
        # Sort starting from all vertices one by one
        for v_id in self.VERTEX:
            if not visited[v_id]:
                self.topological_sort_util(v_id, visited, stack)

        return stack

    def get_info(self):
        return len(self.VERTEX), len(self.EDGE)

    def print(self):
        print(self.VERTEX)
        print(self.EDGE)
        print(self.DEGREE)
