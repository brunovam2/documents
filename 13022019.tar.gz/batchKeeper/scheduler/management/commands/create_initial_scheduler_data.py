from django.core.management.base import BaseCommand, CommandError
from scheduler.models import BatchStatus, JobStatus, Resource, Batch, Job, Host, HostStatus
from decimal import *


class Command(BaseCommand):
    help = 'Create initial needed data into the database'

    def add_arguments(self, parser):
        pass

    # def insert_default_task_status(self):
    #     status_names = ["sent","executing","success","partially_success", "failed"]
    #     for s_name in status_names:
    #         if not BatchStatus.objects.filter(name=s_name).count():
    #             status = BatchStatus()
    #             status.name=s_name
    #             status.save()
    #
    #
    # def insert_default_job_status(self):
    #     status_names = ["queued","executing","executed","failed"]
    #     for s_name in status_names:
    #         if not JobStatus.objects.filter(name=s_name).count():
    #             status = JobStatus()
    #             status.name=s_name
    #             status.save()
    #
    # def insert_default_executor_status(self):
    #     status_names = ["queued2deploy","running","disconected","failed"]
    #     for s_name in status_names:
    #         if not ExecutorStatus.objects.filter(name=s_name).count():
    #             status = ExecutorStatus()
    #             status.name=s_name
    #             status.save()

    def insert_default_resource(self):
        if not Resource.objects.filter(name="DEFAULT").count():
            r = Resource()
            r.name = "DEFAULT"
            r.cpu = Decimal(1)
            r.memory = Decimal(256)
            r.disk = Decimal(256)
            r.save()

    def insert_default_host(self):
        if not Host.objects.filter(hostname="localhost").count():
            h = Host()
            h.hostname = "localhost"
            h.ip = "127.0.0.1"
            h.status = HostStatus.RUNNING
            h.cpu = Decimal(8)
            h.memory = Decimal(4096)
            h.disk = Decimal(5000)
            h.save()
            h.enabled = True

    def handle(self, *args, **options):
        # self.insert_default_batch_status()
        # self.insert_default_job_status()
        self.insert_default_resource()
        self.insert_default_host()
        # self.insert_default_executor_status()

        self.stdout.write(self.style.SUCCESS('Successfully created initial data'))
