from django.core.management.base import BaseCommand, CommandError
from django.db import transaction
from batch_keeper.settings import TIMEOUT_WAITING_FOR_AGENT, SERVER_HOSTNAME, BASE_DIR
from scheduler.models import BatchStatus, JobStatus, Resource, Batch, BatchGroup, Job, Repetition, Host,\
    BatchGroupExecutionOrder, JobDependency
from eca.models import BatchEvent, JobEvent, ObjectType, Log
from executor.models import BatchExecution, JobExecution, JobExecutionDetails,\
 JobExecutionDetailsStatus
from executor.api import Signalize
from .lib.graph import Graph
from .lib.vertex import Vertex
import functools
import time
from datetime import datetime, timedelta
import subprocess, shlex
import reversion
import multiprocessing
import logging
from itertools import chain
import copy
import paramiko
import uuid


#TODO: RENAME THESE VARIABLES!!!!l
JOB_EXECTION_TRIES = 20
SLEEP_JOB_EXECUTION_TRIES = 60
batch_object_type = ObjectType.objects.get(name="BATCH")
job_object_type = ObjectType.objects.get(name="JOB")
batch_queued_event = BatchEvent.objects.get(name="batch_queued")
exceeded_deadline_event = BatchEvent.objects.get(name="batch_deadline_exceeded")
exceeded_deadline_event = JobEvent.objects.get(name="job_deadline_exceeded")
exceeded_expected_duration_time_event = JobEvent.objects.get(name="job_expected_duration_time_exceeded")
exceeded_expected_duration_time_event = BatchEvent.objects.get(
                            name="batch_expected_duration_time_exceeded")
batch_executing_event = BatchEvent.objects.get(name="batch_executing")
batch_executed_event = BatchEvent.objects.get(name="batch_executed")
batch_failed_event = BatchEvent.objects.get(name="batch_failed")
batch_parcially_executed = BatchEvent.objects.get(name="batch_parcially_executed")
batch_disabled = BatchEvent.objects.get(name="batch_disabled")

# This decorator can be applied to
def with_logging(func):
    @functools.wraps(func)
    def wrapper(*args, **kwargs):
        # print('LOG: Running job "%s"' % func.__name__)
        result = func(*args, **kwargs)
        # print('LOG: Job "%s" completed' % func.__name__)
        return result
    return wrapper


class Command(BaseCommand):
    """
    This command executes the BK batch/jobs
    """
    help = 'Start the remote execution of batches'

    @staticmethod
    def execution_graph(batch_or_batch_group):
        g = Graph()
        jobs_vertices = []
        if isinstance(batch_or_batch_group, BatchGroup):
            dependencies = BatchGroupExecutionOrder.objects.filter(batch_group=batch_or_batch_group)
        else:
            dependencies = JobDependency.objects.filter(batch=batch_or_batch_group)
            jobs_of_batch = Job.objects.filter(batch=batch_or_batch_group).order_by('-id')

            for j in jobs_of_batch:
                jobs_vertices
                g.add_vertex(Vertex(id=j.id))

        for d in dependencies:
            if d.predecessor.id in g.VERTEX:
                v1 = g.VERTEX[d.predecessor.id]
            else:
                v1 = Vertex(id=d.predecessor.id)
                g.add_vertex(v1)
            if d.successor.id in g.VERTEX:
                v2 = g.VERTEX[d.successor.id]
            else:
                v2 = Vertex(id=d.successor.id)
                g.add_vertex(v2)

            g.add_edge(v1, v2)

        return g

    #@staticmethod
    def execute_job(self, job, batch_execution):
        j = job
        j.status = JobStatus.EXECUTING
        j.save(update_fields=['status'])
        j.start_time = datetime.now()
        job_execution = Signalize.job_execution(job, batch_execution)
        # TODO: Choose the best available host to execute the batches
        if not j.host:
            # TODO: Ordenar em ordem crescente da diferença entre cpu, memoria e disco entre os dados do host e do job
            available_machines = Host.objects.filter(enabled=True, cpu__gte=j.minimum_requirements.cpu,
                                                     memory__gte=j.minimum_requirements.memory,
                                                     disk__gte=j.minimum_requirements.disk)
            if available_machines:
                j.host = available_machines[0]
            else:
                execution_tries = 0
                while True:
                    available_machines = Host.objects.filter(enabled=True, cpu__gte=j.minimum_requirements.cpu,
                                                             memory__gte=j.minimum_requirements.memory,
                                                             disk__gte=j.minimum_requirements.disk)
                    if available_machines:
                        break
                    else:
                        if execution_tries >= JOB_EXECTION_TRIES:
                            j.status = JobStatus.FAILED
                            j.output_err = "No available machine to execute the job %s" % str(j.id)
                            j.save(update_fields=['status', 'output_err'])
                            Signalize.job_execution({"batch_execution": batch_execution, "job": job})
                            return
                        execution_tries += 1
                        time.sleep(SLEEP_JOB_EXECUTION_TRIES)

        else:
            if not j.host.enabled:
                print("JOB ERROR: The Host of the batch %s is disabled" % str(j.id))
                Signalize.job_execution(job, batch_execution, job_execution.uuid)
            else:
                execution_tries = 0
                while not (j.host.cpu >= j.minimum_requirements.cpu and
                        j.host.memory >= j.minimum_requirements.memory and
                        j.host.disk >= j.minimum_requirements.disk):

                    if execution_tries >= JOB_EXECTION_TRIES:
                        print("JOB ERROR: The Host %s hasn't the available minimum requirements for the execution "
                              "of the job %s of the batch %s" % (j.host.hostname, j.id, j.batch.id))
                        j.status = JobStatus.FAILED
                        j.output_err = "JOB ERROR: The Host %s hasn't the available minimum requirements for the " \
                                       "execution of the job %s of the batch %s" % (j.host.hostname, j.id,
                                                                                    j.batch.id)
                        j.save(update_fields=['status', 'output_err'])
                        Signalize.job_execution(job, batch_execution, job_execution.uuid)
                        return
                    else:
                        execution_tries += 1
                        time.sleep(SLEEP_JOB_EXECUTION_TRIES)
                else:
                    print("The host %s has the minimum requirements for the job %s of the batch %s"
                          " execution" % (j.host.hostname, j.id, j.batch.id))
                    Signalize.job_execution(job, batch_execution, job_execution.uuid)

        if j.docker_container_name:
            command = shlex.split("ssh %s 'docker exec %s %s %s'" % (j.host.hostname,
                                                                     j.docker_container_name,
                                                                     j.command, j.arguments))
        else:
            command = shlex.split("ssh %s '%s %s'" % (j.host.hostname, j.command, j.arguments))

        print("Executing %s: %s" % (j.nickname, str(command)))
        ssh = paramiko.SSHClient()
        ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        ssh.connect(j.host.hostname, username='bruno', password='senha')
        sftp = ssh.open_sftp()
        sftp.put("%s/job_executor/exec.py" % (BASE_DIR,), "/tmp/exec.py")
        stdin, stdout, stderr = ssh.exec_command("chmod +x /tmp/exec.py")
        stdin, stdout, stderr = ssh.exec_command("python3 /tmp/exec.py %s \"%s\" %s" % (SERVER_HOSTNAME, ' '.join(command), job_execution.uuid))
        print(stdin, stdout, stderr)
        print("python3 /tmp/exec.py %s \"%s\" %s" % (SERVER_HOSTNAME, ' '.join(command), job_execution.uuid))

        TIMEOUT_WAITING_FOR_AGENT=72000
        job_execution_details = JobExecutionDetails.objects.get(job_execution=job_execution)
        while True:
            job_execution_details.refresh_from_db()
            if TIMEOUT_WAITING_FOR_AGENT <= 0:#TODO: ADICIONAR UM EVENTO PARA ISSO
                print("TIMEOUT")
                j.status_code = 1
                j.execution_finish_time = datetime.now()
                j.save()
                j.status = JobStatus.FAILED
                j.save(update_fields=['status'])
                Signalize.job_execution(job, batch_execution, job_execution.uuid)
                return None
            elif job_execution_details.agent_port:#The agent sent the basic execution info
                print("INFORMACAO DE AGENTE RECEBIDA")
                break
            time.sleep(1)
            print("Esperando 1 segundo")
            TIMEOUT_WAITING_FOR_AGENT -= 1
        
        #while job_execution_details.status != JobExecutionDetailsStatus.objects.get(name="EXECUTING"):
        while Job.objects.get(id=j.id).status == JobStatus.EXECUTING:
            print("AGUARDANDO EXECUCAO DE JOB")
            time.sleep(10)
        print("ENCERRANDO THREAD DE EXECUCAO DE JOB")
        Signalize.job_execution(job, batch_execution, job_execution.uuid)
        return None
        # j.output = str(std_out, errors='ignore')
        # j.output_err = str(std_err, errors='ignore')
        # j.status_code = pipes.returncode
        # j.execution_finish_time = datetime.now()
        # j.save()
        # Signalize.job_execution({"batch_execution": batch_execution, "job": job})

        # if pipes.returncode != 0:
        #     j.status = JobStatus.FAILED
        # else:
        #     j.status = JobStatus.EXECUTED
        # j.save(update_fields=['status'])
        # Signalize.job_execution({"batch_execution": batch_execution, "job": job})

    #@staticmethod
    def execute_batch(self, batch):
        batch.status = BatchStatus.EXECUTING
        batch.save()
        batch.refresh_from_db()
        with reversion.create_revision(atomic=False):
            # Store some meta-information.
            # reversion.set_user(request.user)
            reversion.set_comment("Batch %s execution at %s" % (batch.id, str(datetime.now())))
            if not len(Host.objects.all()):
                print("CRITICAL ERROR: No registered Host")
                return
            Log.log_event(batch_object_type, batch.id, batch_executing_event.id, "Batch execution started")
            print("Executando uma tarefa")
            batch.execution_start_time = datetime.now()
            batch.status = BatchStatus.EXECUTING
            batch.save(update_fields=['status', 'execution_start_time'])
            batch_execution = Signalize.batch_execution(batch)

            had_successful_job = False
            had_failed_job = False
            try:
                print("Executing " + batch.nickname)
                job_execution_graph = Command.execution_graph(batch)
                # jobs_zero_degrees = []
                # for j in job_execution_graph.DEGREE[0]:
                #     jobs_zero_degrees.append(j)
                jobs_zero_degrees = copy.deepcopy(job_execution_graph.DEGREE[0])
                while jobs_zero_degrees:
                    job_id = jobs_zero_degrees.pop()
                    # j = Job.objects.get(id=job_id)
                    jobs_queue = [job_id]
                    while jobs_queue:
                        job_id = jobs_queue.pop()
                        j = Job.objects.get(id=job_id)
                        self.execute_job(j, batch_execution)#thread?
                        j = Job.objects.get(id=job_id)
                        if j.status == JobStatus.EXECUTED:
                            had_successful_job = True
                            j_vertex = job_execution_graph.VERTEX[j.id]
                            next_jobs_id = job_execution_graph.EDGE[j.id]
                            for neighbour_job_id in next_jobs_id:
                                neighbour_vertex = job_execution_graph.VERTEX[neighbour_job_id]
                                job_execution_graph.del_edge(j_vertex, neighbour_vertex)
                            job_execution_graph.del_vertex(j_vertex)
                        elif j.status == JobStatus.FAILED:
                            had_failed_job = True
                            # Del every dependent job of the graph in order not to be executed
                            jobs2remove = [job_execution_graph.VERTEX[j.id]]
                            while jobs2remove:
                                j = jobs2remove.pop()
                                next_jobs_id = job_execution_graph.EDGE[j.id]
                                for neighbour_job_id in next_jobs_id:
                                    jobs2remove.append(job_execution_graph.VERTEX[neighbour_job_id])
                                job_execution_graph.del_vertex(j.id)
                        else:
                            import pdb; pdb.set_trace()
                            print("EITAAAAA")

                        jobs_queue = copy.deepcopy(job_execution_graph.DEGREE[0])
                    jobs_zero_degrees = copy.deepcopy(job_execution_graph.DEGREE[0])
            except Exception as e:
                print(str(e))
                batch.status = BatchStatus.FAILED
                Log.log_event(batch_object_type, batch.id, batch_failed_event.id, "Batch execution failed")
                Signalize.batch_execution(batch, batch_execution.uuid)
            finally:
                if had_successful_job and had_failed_job:
                    batch.status = BatchStatus.PARTIALLY_SUCCESS
                    Log.log_event(batch_object_type, batch.id, batch_parcially_executed.id, "Batch execution succeded")
                elif had_successful_job and not had_failed_job:
                    batch.status = BatchStatus.SUCCESS
                    Log.log_event(batch_object_type, batch.id, batch_executed_event.id, "Batch execution succeded")
                else:
                    batch.status = BatchStatus.FAILED
                    Log.log_event(batch_object_type, batch.id, batch_failed_event.id, "Batch execution failed")

                print("LAST_EXECUTION: %s" % batch.last_execution)
                batch.last_execution = datetime.now()
                batch.execution_finish_time = datetime.now()
                batch.save(update_fields=['status', 'last_execution', 'execution_finish_time'])
                Signalize.batch_execution(batch, batch_execution.uuid)
                print("LAST_EXECUTION: %s" % batch.last_execution)
                if batch.repetition == Repetition.ONE_TIME:
                    batch.enabled = False
                    batch.save(update_fields=['enabled'])
                    Signalize.batch_execution(batch, batch_execution.uuid)
                    Log.log_event(batch_object_type, batch.id, batch_disabled.id, "Batch disabled")

    # @transaction.atomic
    # @with_logging
    # @staticmethod
    def execute_batches_or_batch_groups(self, batch_or_batch_group):
        if isinstance(batch_or_batch_group, BatchGroup):
            batch_execution_graph = Command.execution_graph(batch_or_batch_group)
            l = batch_execution_graph.topological_sort()
            for batch_id in batches_id_ordered:
                self.execute_batch(Batch.objects.get(id=batch_id))
        else:
            self.execute_batch(batch_or_batch_group)

    # @staticmethod
    # def run_threaded(job_func, arguments):
    #     job_thread = threading.Thread(target=job_func, args=(arguments,))
    #     job_thread.start()
    #
    # def add_arguments(self, parser):
    #     pass

    def diff_months(self, date1, date2):
        return (date2.year - date1.year) * 12 + (date2.month - date1.month)

    @staticmethod
    def update_execution_queue():

        while True:
            enabled_batches = Batch.objects.filter(enabled=True).exclude(status__in=[BatchStatus.QUEUED,
                                                                                     BatchStatus.EXECUTING])
            #enabled_batches.refresh_from_db()
            enabled_batch_groups = BatchGroup.objects.filter(enabled=True).exclude(status__in=[BatchStatus.QUEUED,
                                                                                               BatchStatus.EXECUTING])
            #enabled_batch_groups.refresh_from_db()

            now = datetime.now()

            for t in chain(enabled_batches, enabled_batch_groups):
                # E se eu cadastrar uma tarefa pra rodar às 23:59? Ela pode não rodar no dia!
                # Verificar se ficou alguma tarefa sem rodar no dia anterior?
                # Verificar no log de execução e rodar as tarefas que eram pra serem executadas entre a ultima execucao
                #  e a atual?

                if t.start_time.time() > now.time():
                    continue

                not_executed_today = True if not t.last_execution else (t.last_execution.date() != now.date())
                condition = False
                if t.repetition == Repetition.YEARLY:
                    condition = (not_executed_today
                        and now.month == t.start_time.month
                        and now.day == t.start_time.day
                        and (now.year - t.start_time.year) % t.repetition_interval == 0)
                elif t.repetition == Repetition.MONTHLY:
                    condition = (t.start_time.day == now.day
                        and not_executed_today
                        and ((now.year - t.start_time.year) * 12 + (
                                    now.month - t.start_time.month)) % t.repetition_interval == 0)
                elif t.repetition == Repetition.WEEKLY:
                    condition = (t.start_time.weekday == now.weekday
                        and not_executed_today
                        and ((now.date() - t.start_time.date()).days /7) % t.repetition_interval == 0)
                elif t.repetition == Repetition.DAILY:
                    condition = ( not_executed_today
                        and (now.date() - t.start_time.date()).days % t.repetition_interval == 0)
                elif t.repetition == Repetition.HOURLY:
                    condition = (t.last_execution.hour != now.hour)
                elif t.repetition == Repetition.ONE_TIME:
                    condition = now.date() == t.start_time.date()
                else:
                    #TODO: Escrever na tabela de logs
                    print("Critical error! The following repetition is unknown: %s" % t.repetition)

                if condition:
                    t.status = BatchStatus.QUEUED
                    t.save(update_fields=['status'])
                    Log.log_event(batch_object_type, t.id, batch_queued_event.id, "Batch queued for execution")
                    #Signalize.batch_execution()
            time.sleep(30)


    @staticmethod
    def verify_running_batches():
        while True:
            executing_batches = Batch.objects.all().filter(enabled=True, status=BatchStatus.EXECUTING)
            for batch in executing_batches:
                batch.refresh_from_db()
                batch_duration_until_now = batch.execution_start_time + (datetime.now() - batch.execution_start_time)
                if not batch.deadline and not batch.deadline:
                    continue

                if batch.expected_duration_time:
                    if batch.expected_duration_time < batch_duration_until_now:
                        Log.log_event(
                            batch_object_type, batch.id, exceeded_expected_duration_time_event.id, "Batch expected duration time exceeded")
                if batch.deadline:
                    if batch.deadline < batch_duration_until_now:
                        Log.log_event(batch_object_type, batch.id, exceeded_deadline_event.id, "Batch max duration time exceeded")

                for job in Job.objects.filter(batch=batch):
                    job_duration_until_now = job.start_time + (datetime.now() - job.start_time)
                    if job.expected_duration_time < job_duration_until_now:
                        Log.log_event(
                            job_object_type, job.id, exceeded_expected_duration_time_event.id, "Job expected duration time exceeded")
                    if job.deadline < job_duration_until_now:
                        Log.log_event(job_object_type, job.id, exceeded_deadline_event.id, "Job deadline exceeded")
            time.sleep(60)

    def handle(self, *args, **options):
        multiprocessing.log_to_stderr(logging.INFO)

        p = multiprocessing.Process(target=self.verify_running_batches)
        p.start()

        #self.verify_running_batches()

        # self.update_execution_queue()

        execution_queue_updater_thread = multiprocessing.Process(target=self.update_execution_queue)
        execution_queue_updater_thread.start()
        
        while True:
            jobs = []
            batches2run = chain(BatchGroup.objects.filter(
                status=BatchStatus.QUEUED).order_by('-priority'),
                Batch.objects.filter(status=BatchStatus.QUEUED).order_by('-priority')
                )
            for batch in batches2run:
                self.execute_batches_or_batch_groups(batch)
                # p = multiprocessing.Process(target=self.execute_batches_or_batch_groups, args=(batch,))
                # jobs.append(p)
                # p.start()
                while batch.status == BatchStatus.QUEUED:
                    time.sleep(2)
                    batch.refresh_from_db()
                #self.run_threaded(self.execute_batch, {execution_queue[batch_id]})
                #self.run_threaded(self.execute_batch, {execution_queue[batch_id]})
            time.sleep(5)
