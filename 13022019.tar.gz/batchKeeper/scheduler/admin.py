# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from .models import Batch, BatchGroup, Job, Host, Resource, BatchGroupExecutionOrder, JobDependency
from django.contrib import admin
from reversion.admin import VersionAdmin


@admin.register(Host)
class HostAdmin(VersionAdmin):
    list_display = ('hostname', 'ip', 'status', 'cpu', 'memory', 'disk', 'enabled')
    list_filter = ('enabled', 'status')
    search_fields = ['hostname', 'ip', 'status', 'cpu', 'memory', 'disk']


@admin.register(Resource)
class ResourceAdmin(VersionAdmin):
    list_display = ('name', 'cpu', 'memory', 'disk')
    search_fields = ['name']


@admin.register(Batch)
class BatchAdmin(VersionAdmin):
    list_display = ('id', 'nickname', 'priority', 'start_time', 'status', 'owner_name', 'enabled')
    list_filter = ('enabled', 'status')
    search_fields = ['nickname', 'description', 'start_time', 'status', 'owner', 'owner_name', 'enabled']
    exclude=("real_start_time", "finish_time", "status", "last_execution", )
    #readonly_fields=("real_start_time", "finish_time", "status", "last_execution", )


@admin.register(BatchGroup)
class BatchGroupAdmin(VersionAdmin):
    list_display = ('id', 'nickname', 'priority', 'start_time', 'status', 'owner_name', 'enabled')
    list_filter = ('enabled', 'status')
    search_fields = ['nickname', 'description', 'start_time', 'status', 'owner', 'owner_name', 'enabled']
    exclude=("real_start_time", "finish_time", "status", "last_execution", )
    #readonly_fields=("real_start_time", "finish_time", "status", "last_execution", )


@admin.register(Job)
class JobAdmin(VersionAdmin):
    #list_display = ('id', 'nickname', 'batch', "start_time", "finish_time", "status_code", "status")
    list_filter = ('status','status_code')
    search_fields = ['nickname', 'task__description', 'task__nickname', 'execution_start_time', "execution_finish_time", "output", "output_err"]
    #exclude=("status", "start_time", "finish_time", "output", "output_err", "status_code")
    readonly_fields=("status", "execution_start_time", "execution_finish_time", "output", "output_err", "status_code")


@admin.register(BatchGroupExecutionOrder)
class BatchGroupAdmin(VersionAdmin):
    list_display = ('id', 'batch_group', 'predecessor', 'successor')
    search_fields = ['batch_group', 'predecessor', 'successor']


@admin.register(JobDependency)
class JobDependencyAdmin(VersionAdmin):
    list_display = ('id', 'batch', 'predecessor', 'successor')
    search_fields = ['group', 'predecessor', 'successor']
