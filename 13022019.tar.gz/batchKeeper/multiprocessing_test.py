#multiprocessing_log_to_stderr.py

import multiprocessing
import logging
import sys


def worker():
    print('Doing some work')
    sys.stdout.flush()


if __name__ == '__main__':
    jobs = []
    multiprocessing.log_to_stderr(logging.INFO)
    for i in range(5):
        p = multiprocessing.Process(target=worker)
        jobs.append(p)
        p.start()

    for j in jobs:
        j.join()

