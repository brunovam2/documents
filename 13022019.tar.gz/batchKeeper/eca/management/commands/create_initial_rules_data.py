from django.core.management.base import BaseCommand, CommandError
from eca.models import BatchEvent, JobEvent, ObjectType, ExecutionStatus, Action, Condition, EventType
from executor.models import JobExecutionDetailsStatus


class Command(BaseCommand):
    help = 'Create initial needed data into the database'

    def add_arguments(self, parser):
        pass

    def insert_default_event_types(self):
        event_names = ["RECURRENT","NOT_RECURRENT"]
        for e_name in event_names:
            if not EventType.objects.filter(name=e_name).count():
                event = EventType()
                event.name=e_name
                event.save()

    def insert_default_job_execution_details_status(self):
        event_names = ["NO_AGENT_INFO","EXECUTING","EXECUTED","ABORTED"]
        for e_name in event_names:
            if not JobExecutionDetailsStatus.objects.filter(name=e_name).count():
                event = JobExecutionDetailsStatus()
                event.name=e_name
                event.save()

    def insert_default_job_events(self):
        event_names = ["job_changed_field","job_deadline_exceeded","job_expected_duration_time_exceeded","job_executed","job_executing","job_failed"]
        for e_name in event_names:
            if not JobEvent.objects.filter(name=e_name).count():
                event = JobEvent()
                event.name=e_name
                event.e_type=EventType.objects.get(name="NOT_RECURRENT")
                event.save()

    def insert_default_batch_events(self):
        event_names = ["batch_changed_field","batch_deadline_exceeded","batch_expected_duration_time_exceeded","batch_queued","batch_executed","batch_executing","batch_failed","batch_parcially_executed","batch_disabled"]
        for e_name in event_names:
            if not BatchEvent.objects.filter(name=e_name).count():
                event = BatchEvent()
                event.name=e_name
                event.e_type=EventType.objects.get(name="NOT_RECURRENT")
                event.save()

    # def insert_default_scheduler_events(self):
    #     event_names = ["maintanance"]
    #     for e_name in event_names:
    #         if not SchedulerEvent.objects.filter(name=e_name).count():
    #             event = SchedulerEvent()
    #             event.name=e_name
    #             event.save()

    def insert_default_object_type_names(self):
        names = ["BATCH","BATCH_GROUP","JOB","MONITORING","SCHEDULER","OTHERS","BATCH_RULE","JOB_RULE"]
        for obj_name in names:
            if not ObjectType.objects.filter(name=obj_name).count():
                obj_type = ObjectType()
                obj_type.name=obj_name
                obj_type.save()

    def insert_default_status_action_execution(self):
        status_list = ["SUCCESS","FAILED","ABORTED","EXECUTING","WILL_EXECUTE","PARTIALLY_SUCCESS"]
        for status in status_list:
            if not ExecutionStatus.objects.filter(name=status).count():
                status_action = ExecutionStatus()
                status_action.name=status
                status_action.save()

    def insert_example_action(self):
        if not Action.objects.filter(nickname="example").count():
            a = Action()
            a.nickname = "example"
            a.description = "Example action"
            a.filename = "example.py"
            a.save()

    def insert_example_condition(self):
        if not Condition.objects.filter(nickname="example").count():
            c = Condition()
            c.nickname = "example"
            c.description = "Example condition"
            c.filename = "example.py"
            c.function_name = "example_of_condition"
            c.function_args = None
            c.save()

    def insert_send_email_processing_failed_action(self):
        if not Action.objects.filter(nickname="send_email_processing_failed").count():
            a = Action()
            a.nickname = "send_email_processing_failed"
            a.description = "Envia um e-mail quando o processamento falhar"
            a.filename = "send_email_processing_failed.py"
            a.save()

    def insert_send_email_processing_succeeded_action(self):
        if not Action.objects.filter(nickname="send_email_processing_succeeded").count():
            a = Action()
            a.nickname = "send_email_processing_succeeded"
            a.description = "Envia um e-mail quando o processamento ocorrer com sucesso"
            a.filename = "send_email_processing_succeeded.py"
            a.save()

    def insert_send_email_database_parameter_change_failed_action(self):
        if not Action.objects.filter(nickname="send_email_database_parameter_change_failed").count():
            a = Action()
            a.nickname = "send_email_database_parameter_change_failed"
            a.description = "Envia um e-mail quando ocorrer algum erro na alteracao dos parametros 252 ou 253 no banco de dados"
            a.filename = "send_email_database_parameter_change_failed.py"
            a.save()

    def insert_reschedule_batch_next_day_action(self):
        if not Action.objects.filter(nickname="reschedule_batch_next_day").count():
            a = Action()
            a.nickname = "reschedule_batch_next_day"
            a.description = "Reagenda a execução de determinada tarefa para o proximo dia"
            a.filename = "reschedule_batch_next_day.py"
            a.save()

    def insert_reschedule_batch_next_hour_action(self):
        if not Action.objects.filter(nickname="reschedule_batch_next_hour").count():
            a = Action()
            a.nickname = "reschedule_batch_next_hour"
            a.description = "Reagenda a execução de determinada tarefa para a proximo hora"
            a.filename = "reschedule_batch_next_hour.py"
            a.save()


    def insert_batch_job_failed_condition(self):
        if not Condition.objects.filter(nickname="batch_job_failed").count():
            c = Condition()
            c.nickname = "batch_job_failed"
            c.description = "Retorna verdadeiro quando uma tarefa ou job falhou em sua execucao"
            c.filename = "batch_job.py"
            c.function_name = "batch_job_failed"
            c.function_args = None
            c.save()

    def insert_batch_job_succeeded_condition(self):
        if not Condition.objects.filter(nickname="batch_job_succeeded").count():
            c = Condition()
            c.nickname = "batch_job_succeeded"
            c.description = "Retorna verdadeiro quando uma tarefa ou job foi executada com sucesso"
            c.filename = "batch_job.py"
            c.function_name = "batch_job_succeeded"
            c.function_args = None
            c.save()

    def handle(self, *args, **options):
        self.insert_default_event_types()
        self.insert_example_action()
        self.insert_example_condition()
        self.insert_send_email_processing_failed_action()
        self.insert_send_email_processing_succeeded_action()
        self.insert_send_email_database_parameter_change_failed_action()
        self.insert_reschedule_batch_next_hour_action()
        self.insert_reschedule_batch_next_day_action()
        self.insert_batch_job_failed_condition()
        self.insert_batch_job_succeeded_condition()
        self.insert_default_job_events()
        self.insert_default_batch_events()
       # self.insert_default_scheduler_events()
        self.insert_default_object_type_names()
        self.insert_default_status_action_execution()
        self.insert_default_job_execution_details_status()

        self.stdout.write(self.style.SUCCESS('Successfully created initial data'))
