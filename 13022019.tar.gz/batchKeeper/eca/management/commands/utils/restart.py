class RestartBatch():
    pass

class RestartJob():
    pass