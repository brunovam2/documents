import requests
from scheduler.models import Repetition


class Schedule(object):

    def add(batch):
        #Check if the system host is already added to the Scheduler. If not, add it and get its ID.
        requests.packages.urllib3.disable_warnings()
        session = requests.Session()
        session.trust_env = False
        r = session.get("%s/%s/host/" % (OLIVE_URL, OLIVE_API), verify=False)
        response = r.json()

        host_id = None
        for host in response:
            if host["id"] == system.machine.id:
                host_id = host["id"]

        if not host_id:
            host_data = {}
            host_data["id"] = str(system.machine.id)
            host_data["hostname"] = system.machine.hostname
            host_data["ip"] = system.machine.ip
            r = session.post("%s/%s/host/" % (OLIVE_URL, OLIVE_API), json=host_data, verify=False)
            if session.status_code != 201:
                print("Error creating host into the scheduler. Status: %s. Request data: %s" % (str(session.status_code), str(host_data)))
                return False
            host_id = json.loads(r.text)['id']

        start_time = datetime.now()
        start_time += + relativedelta(months=+1)
        start_time.day = system.dia_corte

        batch_mov_data = {}
        batch_mov_data["nickname"] = "Movimento - %s" % system.cnpj
        batch_mov_data["description"] = "Processamento do movimento de %s" % system.cnpj
        batch_mov_data["repetition"] = Repetition.MONTHLY
        # batch_mov_data["timezone"] =
        batch_mov_data["start_time"] = str(start_time)
        batch_mov_data["owner"] = "Automacao"
        batch_mov_data["owner_name"] = "automacao@zetrasoft.com.br"
        batch_mov_data["host"] = str(host_id)
        #Ao adicionar uma tarefa, o Scheduler deverá retornar o uuid da nova tarefa criada.
        r = session.post("%s/%s/batch/" % (OLIVE_URL, OLIVE_API), json=batch_mov_data, verify=False)
        if session.status_code != 201:
            print("Error creating host into the scheduler. Status: %s. Request data: %s" % (str(session.status_code), str(batch_mov_data)))
            return False
        batch_id = json.loads(r.text)['id']

        job_data = {}
        job_data["nickname"] = "Movimento - %s" % system.cnpj
        job_data["description"] = "Processamento do movimento de %s" % system.cnpj
        job_data["priority"] = 1
        job_data["batch"] = batch_id
        job_data["docker_container_name"] = system.docker_container_name
        job_data["command"] = "/home/eConsig/admin/exp/%s/mov_fin.sh" % system.cnpj
        job_data["arguments"] = "-e"

        r = session.post("%s/%s/job/" % (OLIVE_URL, OLIVE_API), json=batch_mov_data, verify=False)
        if session.status_code != 201:
            print("Error creating host into the scheduler. Status: %s. Request data: %s" % (str(session.status_code), str(job_data)))
            return False

        return True
