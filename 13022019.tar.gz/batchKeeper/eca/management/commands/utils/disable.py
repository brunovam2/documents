class DisableBatch():
    pass

class DisableJob():
    pass

class DisableRule():
    pass