

class Workflow():

    @staticmethod
    def match_rules():
        pass
