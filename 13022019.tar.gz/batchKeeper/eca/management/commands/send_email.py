from django.core.management.base import BaseCommand, CommandError
from eca.models import Event
from scheduler.models import Batch, BatchStatus, Job, JobStatus
from django.core.mail import send_mail


class Command(BaseCommand):
    help = 'Create initial needed data into the database'

    def add_arguments(self, parser):
        parser.add_argument('destination', nargs='+', type=str)
        parser.add_argument('subject', nargs='+', type=str)
        parser.add_argument('message', nargs='+', type=str)
        parser.add_argument('batch_pk', nargs='+', type=str)
        #parser.add_argument('job_pk', nargs='+', type=str)
        # Named (optional) arguments
        #parser.add_argument(
        #    '--destination',
        #    action='store_true',
        #    dest='destination',
        #    default=False,
        #    help='Destination email',
        #)

        #parser.add_argument(
        #    '--subject',
        #    action='store_true',
        #    dest='subject',
        #    default=False,
        #    help='Email subject',
        #)

        #parser.add_argument(
        #    '--message',
        #    action='store_true',
        #    dest='message',
        #    default=False,
        #    help='Email message',
        #)

    def handle(self, *args, **options):
        sender = "automatizacao@zetrasoft.com.br"
        if options['destination'] and options['subject'] and options['message']:
            msg = options['subject'][0]
            if "batch_pk" in options:
                msg = "%s para %s" % (msg, BatchStatus.get_name(Batch.objects.get(id=options['batch_pk'][0]).status))
            elif "job_pk" in options:
                msg = "%s para %s" % (msg, JobStatus.get_name(Job.objects.get(id=options['job_pk'][0]).status))
            send_mail(
                options['destination'][3],#Subject
                msg,
                sender,
                [options['destination'][1]],
                fail_silently=False,
            )
