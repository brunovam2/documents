from django.core.management.base import BaseCommand, CommandError
from datetime import datetime
from eca.models import BatchEvent, JobEvent, SchedulerEvent, ObjectType, Log, LogActionExecution
from eca.rule_admin import RuleAdmin, BatchJob
from scheduler.models import Batch, Job
from batch_keeper.settings import CLIENT_PATH

class Command(BaseCommand):
    help = 'Create initial needed data into the database'

    def add_arguments(self, parser):
        pass

    @staticmethod
    def verify_match_batch():
        pass

    @staticmethod
    def verify_match_job():
        pass

    @staticmethod
    def verify_match_scheduler():
        pass

    @staticmethod
    def verify_match_monitoring():
        pass


    def handle(self, *args, **options):
        # last_action_execution = LogActionExecution.objects.all().last()
        # log_last_action_execution = last_action_execution.log
        unverified_logs = Log.objects.filter(verified_by_workflow=False)
        for log in unverified_logs:
            if log.object_type.name == "BATCH":
                batch = Batch.objects.get(id=log.object_id)
                event = BatchEvent.objects.get(id=log.event_id)
                rules_matched = RuleAdmin.verify_match_batch(batch, event, log)
                if rules_matched:
                    for r in rules_matched:
                        status, action_execution_info = RuleAdmin.apply(r, BatchJob.BATCH, log)
                        LogActionExecution.log_event(r.action, datetime.now(), log, status, action_execution_info)
            elif log.object_type.name == "JOB":
                job = Job.objects.get(id=log.object_id)
                event = JobEvent.objects.get(id=log.event_id)
                rules_matched = RuleAdmin.verify_match_job(job, event, log)
                if rules_matched:
                    for r in rules_matched:
                        status, action_execution_info = RuleAdmin.apply(r, BatchJob.JOB, log)
                        LogActionExecution.log_event(r.action, datetime.now(), log, status, action_execution_info)
            else:
                print("ERROR: OBJECT NOT RECOGNIZED")
                return 1


            log.verified_by_workflow = True
            log.save()
