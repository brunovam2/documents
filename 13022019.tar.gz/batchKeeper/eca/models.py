from django.db import models
from scheduler.models import Job, Batch, Resource
from django.db.models.signals import post_save
from django.dispatch import receiver
#from .utils import Event
from datetime import datetime
from scheduler.models import BatchStatus, JobStatus


@receiver(post_save, sender=Batch)
def run_batch_rules(sender, **kwargs):
    """
    This method verify the existence of eca related to a modified batch and
    executes them if necessary.
    """
    print("Batch Signal funcionando")
    if kwargs['update_fields']:
        if "status" in kwargs['update_fields']:
            observation_text = ""
            if kwargs['instance'].status == BatchStatus.QUEUED:
                observation_text = "Batch queued for execution"
            elif kwargs['instance'].status == BatchStatus.EXECUTING:
                observation_text = "Executing Batch"
            elif kwargs['instance'].status == BatchStatus.SUCCESS:
                observation_text = "Batch execution succeeded"
            elif kwargs['instance'].status == BatchStatus.PARTIALLY_SUCCESS:
                observation_text = "Batch execution succeeded"
            else:
                observation_text = "Batch execution failed"

            changed_field_event = BatchEvent.objects.get(name="batch_changed_field")
            batch_object_type = ObjectType.objects.get(name="BATCH")
            log = Log.log_event(batch_object_type, kwargs['instance'].id, changed_field_event.id, observation_text)

            from .rule_admin import RuleAdmin, BatchJob
            rules_matched = RuleAdmin.verify_match_batch(kwargs['instance'], changed_field_event, log)
            if rules_matched:
                for r in rules_matched:
                    status, action_execution_info = RuleAdmin.apply(r, BatchJob.BATCH, log)
                    LogActionExecution.log_event(r.action, datetime.now(), log, status, action_execution_info)
            log.verified_by_workflow = True
            log.save()


@receiver(post_save, sender=Job)
def run_job_rules(sender, **kwargs):
    """
    This method verify the existence of eca related to a modified job and
    executes them if necessary.
    """
    print("Job Signal funcionando")
    if kwargs['update_fields']:
        if "status" in kwargs['update_fields']:
            observation_text = ""
            if kwargs['instance'].status == JobStatus.QUEUED:
                observation_text = "Job queued for execution"
            elif kwargs['instance'].status == JobStatus.EXECUTING:
                observation_text = "Executing Job"
            elif kwargs['instance'].status == JobStatus.EXECUTED:
                observation_text = "Job execution succeeded"
            else:
                observation_text = "Job execution failed"

            changed_field_event = JobEvent.objects.get(name="job_changed_field")
            job_object_type = ObjectType.objects.get(name="JOB")
            log = Log.log_event(job_object_type, kwargs['instance'].id, changed_field_event.id, observation_text)

            from .rule_admin import RuleAdmin, BatchJob
            rules_matched = RuleAdmin.verify_match_job(kwargs['instance'], changed_field_event, log)
            if rules_matched:
                for r in rules_matched:
                    status, action_execution_info = RuleAdmin.apply(r, BatchJob.JOB, log)
                    LogActionExecution.log_event(r.action, datetime.now(), log, status, action_execution_info)
            log.verified_by_workflow = True
            log.save()

class EventType(models.Model):
    """
    0 = Recurrent
    1 = Not recurrent
    """
    id = models.AutoField(primary_key=True)
    name = models.CharField(max_length=50)

    def __str__(self):
        return self.name

# class Event(models.Model):
#     id = models.AutoField(primary_key=True)
#     name = models.CharField(max_length=50)
#     e_type = models.ForeignKey(EventType, default=EventType(name="Not recurrent"))

#     def __str__(self):
#         return self.name

class Condition(models.Model):
    id = models.AutoField(primary_key=True)
    nickname = models.CharField(max_length=100)
    description = models.TextField(null=True, blank=True)
    filename = models.CharField(max_length=100)
    function_name = models.CharField(max_length=100)
    function_args = models.CharField(max_length=100, null=True, blank=True)

    def __str__(self):
        return self.nickname

class Action(models.Model):
    id = models.AutoField(primary_key=True)
    nickname = models.CharField(max_length=100)
    description = models.TextField(null=True, blank=True)
    filename = models.CharField(max_length=100)
    args = models.CharField(max_length=100, null=True, blank=True)
    env_args = models.BooleanField(default=True)

    def __str__(self):
        return self.nickname



class BatchEvent(models.Model):
    id = models.AutoField(primary_key=True)
    name = models.CharField(max_length=50)
    e_type = models.ForeignKey(EventType)

    def __str__(self):
        return self.name


class BatchRule(models.Model):
    """
    ECA rule of a Batch
    """
    id = models.AutoField(primary_key=True)
    batch = models.ForeignKey(Batch, on_delete=models.CASCADE)
    event = models.ForeignKey(BatchEvent, on_delete=models.PROTECT)
    condition = models.ForeignKey(Condition, null=True, on_delete=models.PROTECT)
    action = models.ForeignKey(Action, on_delete=models.PROTECT)

    def __str__(self):
        return "%s - %s - %s" % (self.batch.nickname, self.event.name, self.action.nickname)


class JobEvent(models.Model):
    id = models.AutoField(primary_key=True)
    name = models.CharField(max_length=50)
    e_type = models.ForeignKey(EventType)

    def __str__(self):
        return self.name


class JobRule(models.Model):
    """
    ECA rule of a Job
    """
    id = models.AutoField(primary_key=True)
    job = models.ForeignKey(Job, on_delete=models.CASCADE)
    event = models.ForeignKey(JobEvent, on_delete=models.PROTECT)
    condition = models.ForeignKey(Condition, null=True, on_delete=models.PROTECT)
    action = models.ForeignKey(Action, on_delete=models.PROTECT)

    def __str__(self):
        return "%s - %s - %s" % (self.job.nickname, self.event.name, self.action.nickname)


# class SchedulerEvent(models.Model):
#     id = models.AutoField(primary_key=True)
#     name = models.CharField(max_length=50)

#     def __str__(self):
#         return self.name


# class SchedulerRule(models.Model):
#     """
#     ECA rule of a Scheduler
#     """
#     # Um evento pode ser manutenção de servidores por exemplo, máquina que ficou
#     # indisponível, quando não tiver máquinas existentes suficientes para fazer
#     # processamentos e etc..
#     id = models.AutoField(primary_key=True)
#     event = models.ForeignKey(SchedulerEvent, on_delete=models.PROTECT)
#     condition = models.TextField(null=True)
#     action = models.ForeignKey(Action, on_delete=models.PROTECT)

#     def __str__(self):
#         return "%s - %s" % (self.event.name, self.action.nickname)


# class MonitoringEvent(models.Model):
#     id = models.AutoField(primary_key=True)
#     name = models.CharField(max_length=50)

#     def __str__(self):
#         return self.name


# class MonitoringRule(models.Model):
#     """
#     ECA rule of logs
#     """
#     id = models.AutoField(primary_key=True)
#     monitoring = models.ForeignKey(Job, on_delete=models.PROTECT)
#     event = models.ForeignKey(MonitoringEvent, on_delete=models.PROTECT)
#     condition = models.ForeignKey(Condition, null=True, on_delete=models.PROTECT)
#     action = models.ForeignKey(Action, on_delete=models.PROTECT)

#     def __str__(self):
#         return "%s - %s - %s" % (self.monitoring.nickname, self.event.name, self.action.nickname)


class ObjectType(models.Model):
    id = models.AutoField(primary_key=True)
    name = models.CharField(max_length=50)

    def __str__(self):
        return self.name


class ExecutionStatus(models.Model):
    #SUCCESS
    #FAILED
    #ABORTED
    id = models.AutoField(primary_key=True)
    name = models.CharField(max_length=50)

    def __str__(self):
        return self.name


class ExecutionHistory(models.Model):
    object_type = models.ForeignKey(ObjectType, on_delete=models.PROTECT)
    object_id = models.IntegerField(null=True)
    datetime = models.DateTimeField(default=datetime.now())
    status = models.ForeignKey(ExecutionStatus)
    data = models.TextField()


class Log(models.Model):
    """
    Each log can be attached to an ECA rule. It stores every batch/job execution
    and related information
    """
    id = models.AutoField(primary_key=True)
    object_type = models.ForeignKey(ObjectType, on_delete=models.PROTECT)
    object_id = models.IntegerField(null=True)
    event_id = models.IntegerField()
    creation = models.DateTimeField(default=datetime.now())
    data = models.TextField()
    verified_by_workflow = models.BooleanField(default=False)

    @staticmethod
    def log_event(object_type, object_id, event_id, data):
        log = Log()
        log.object_type = object_type
        if object_id:
            log.object_id = object_id
        log.event_id = event_id
        log.data = data
        log.save()

        return log

    def __str__(self):
        return "%s - %d - %d - %s" % (self.object_type.name, self.object_id, self.event_id,  self.creation)


class LogActionExecution(models.Model):
    """
    This class is used to store the logs of actions execution.
    """
    action = models.ForeignKey(Action, on_delete=models.PROTECT)
    datetime = models.DateTimeField()
    log = models.ForeignKey(Log, on_delete=models.PROTECT)
    status = models.ForeignKey(ExecutionStatus, on_delete=models.PROTECT)
    output = models.TextField(null=True)
    output_err = models.TextField(null=True)
    status_code = models.IntegerField(null=True)


    @staticmethod
    def log_event(action, datetime_execution, log, status, action_execution_info):
        log_action = LogActionExecution()
        log_action.action = action
        log_action.datetime = datetime_execution
        log_action.log = log
        log_action.status = status
        if action_execution_info:
            log_action.output = action_execution_info[0]
            log_action.output_err = action_execution_info[1]
            log_action.status_code = action_execution_info[2]
        log_action.save()

        return log_action

    def __str__(self):
        return "%s - %d" % (self.action.nickname, self.log.id)
