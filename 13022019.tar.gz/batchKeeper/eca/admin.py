from django.contrib import admin
from .models import Action, BatchRule, JobRule, Log, Condition, LogActionExecution


class ActionAdmin(admin.ModelAdmin):
    list_display = ('nickname', 'filename', 'args', 'env_args')
    list_filter = ()
    search_fields = ['nickname', 'description', 'filename', 'args', 'env_args']


class ConditionAdmin(admin.ModelAdmin):
    list_display = ('nickname', 'filename', 'function_name', 'function_args')
    list_filter = ()
    search_fields = ['nickname', 'description', 'filename', 'function_name', 'function_args']


class BatchRuleAdmin(admin.ModelAdmin):
    list_display = ('batch', 'event', 'condition', 'action')
    list_filter = ()
    search_fields = ['batch', 'event', 'condition', 'action']


class JobRuleAdmin(admin.ModelAdmin):
    list_display = ('job', 'event', 'condition', 'action')
    list_filter = ()
    search_fields = ['job', 'event', 'condition', 'action']


class LogAdmin(admin.ModelAdmin):
    list_display = ('object_type', 'object_id', 'event_id', 'creation', 'verified_by_workflow')
    list_filter = ()
    search_fields = ['object_type', 'object_id', 'event_id', 'creation', 'verified_by_workflow','data']


class LogActionExecutionAdmin(admin.ModelAdmin):
    list_display = ('action', 'datetime', 'log', 'status', 'status_code')
    list_filter = ('status',)
    search_fields = ['action', 'datetime', 'log', 'status', 'output', 'output_err', 'status_code']


admin.site.register(Action, ActionAdmin)
admin.site.register(Condition, ConditionAdmin)
admin.site.register(BatchRule, BatchRuleAdmin)
admin.site.register(JobRule, JobRuleAdmin)
admin.site.register(Log, LogAdmin)
admin.site.register(LogActionExecution, LogActionExecutionAdmin)
