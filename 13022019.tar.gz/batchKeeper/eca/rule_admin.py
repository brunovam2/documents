import os
import sys
from .utils import Event
from .models import BatchRule, JobRule, Action, ExecutionStatus
from scheduler.models import Job, Batch, Resource, Repetition
from rest_framework.test import APIClient
import requests
from batch_keeper.settings import SCHEDULER_HOSTNAME
from datetime import datetime
import uuid
from batch_keeper.settings import BASE_DIR
from django.db.models.signals import post_save
from django.dispatch import receiver
import json
import subprocess, shlex
from .executor.infrastructure_management import IM


# sys.path.append(CLIENT_PATH)
# sys.path.append("%s/conditions/" % CLIENT_PATH)
# sys.path.append("%s/actions/" % CLIENT_PATH)
class BatchJob(object):
    BATCH=0
    JOB=1


class RuleAdmin(object):

    @staticmethod
    def execute_condition(rule, log, batch_rule):
        """
        Execute a condition (function inside of the BK Client) of a rule and
        return its result (True or False).
        """
        # sys.path.append(CLIENT_PATH)
        # sys.path.append("%s/conditions/" % CLIENT_PATH)
        # sys.path.append("%s/actions/" % CLIENT_PATH)
        #try:
        #    exec("from conditions.%s import %s" % (rule.condition.filename.split(".")[0], rule.condition.function_name))
        #except:
        #    print("ERRO: Nao foi possivel importar a condicao %s.%s" % (rule.condition.filename.split(".")[0], rule.condition.function_name))
        #    return False
        #    # observation_text = "ERRO: Nao foi possivel importar a condicao %s.%s" % (rule.condition.filename.split(".")[0], rule.condition.function_name)
        #    # exceeded_expected_duration_time_event = BatchEvent.objects.get(name="batch_expected_duration_time_exceeded")
        #    # batch_object_type = ObjectType.objects.get(name="BATCH")
        #    # log = Log.log_event(batch_object_type, batch.id, exceeded_expected_duration_time_event.id, observation_text)

        if batch_rule == BatchJob.BATCH:
            default_args = {"batch": rule.batch.pk, "log": log.pk}
        else:
            default_args = {"job": rule.job.pk, "log": log.pk}
        im = IM()
        if rule.condition.function_args:
            command = "cd %s && python3 -c \"from %s import %s;print(eval(\\\"%s(%s, **%s)\\\"))\"" % (im.get_container_conditions_directory(), rule.condition.filename.split(".")[0], rule.condition.function_name, rule.condition.function_name, rule.condition.function_args, str(default_args))
            command = "bash -c \"cd %s && bash ./execute_conditions.sh %s %s \\\"%s\\\" \"" % (im.get_container_conditions_directory(), rule.condition.filename.split(".")[0], rule.condition.function_name, rule.condition.function_args+" "+str(default_args))
        else:
            command = "cd %s && python3 -c \"from %s import %s;print(eval(\\\"%s(**%s)\\\"))\"" % (
            im.get_container_conditions_directory(), rule.condition.filename.split(".")[0], rule.condition.function_name,
            rule.condition.function_name, str(default_args))
            command = command = "bash -c \"cd %s && bash ./execute_conditions.sh %s %s \\\"%s\\\" \"" % (im.get_container_conditions_directory(), rule.condition.filename.split(".")[0], rule.condition.function_name, str(default_args))
        #print(im.run_command("bash -c \"cd %s && bash ./execute_conditions.sh %s %s \\\"%s\\\" \"" % (im.get_container_conditions_directory(), rule.condition.filename.split(".")[0], rule.condition.function_name, rule.condition.function_args+" "+str(default_args))))
        exit_code, output = im.run_command(command)
        print(exit_code, output)
        output = output.decode('UTF-8')
        if output[:4] == "True":
            return True
        else:
            return False


    @staticmethod
    def verify_match_batch(batch, rule_event, log):
        """
        Returns False if no rule be matched or the matched rule
        """
        rules_of_batch = BatchRule.objects.filter(batch=batch.id).filter(event=rule_event)
        matched_rules = []
        if rules_of_batch:
            for r in rules_of_batch:
                condition_statisfied = RuleAdmin.execute_condition(r, log, BatchJob.BATCH)
                if condition_statisfied:
                    matched_rules.append(r)
            return matched_rules

        return False

    @staticmethod
    def verify_match_job(job, rule_event, log):
        """
        Returns False if no rule be matched or the matched rule
        """
        rules_of_job = JobRule.objects.filter(job=job.id).filter(event=rule_event)
        matched_rules = []
        if rules_of_job:
            for r in rules_of_job:
                condition_statisfied = RuleAdmin.execute_condition(r, log, BatchJob.JOB)
                if condition_statisfied:
                    matched_rules.append(r)
            return matched_rules

        return False

    @staticmethod
    def apply(rule, batch_rule, log):
        """
        Execute the action of a rule
        """
        args = ""
        if rule.action.env_args:
            if batch_rule == BatchJob.BATCH:
                args += "-batch %d -log %d" % (rule.batch.pk, log.pk)
            else:
                args += "-job %d -log %d" % (rule.job.pk, log.pk)
        if batch_rule == BatchJob.BATCH:
            if rule.action.args:
                if args:
                    args = "%s %s" % (rule.action.args, args)
                else:
                    args = rule.action.args
        else:
            if rule.action.args:
                if args:
                    args = "%s %s" % (rule.action.args, args)
                else:
                    args = rule.action.args

        im = IM()
        exit_code, output = im.run_command("cd %s && python3 %s %s" % (im.get_container_actions_directory(), rule.action.filename, args))
        im.drop()
        action_execution_info = [output, output, exit_code]
        if exit_code !=0:
            return ExecutionStatus.objects.get(name="FAILED"), action_execution_info
        return ExecutionStatus.objects.get(name="SUCCESS"), action_execution_info

        # command = shlex.split("%s %s %s" % (sys.executable, os.path.join("%sactions" % (CLIENT_PATH), rule.action.filename), args))
        # pipes = subprocess.Popen(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        # std_out, std_err = pipes.communicate()
        # action_execution_info = [std_out, std_err, pipes.returncode]
        # print("Rule %s executed with exit code %d" % (str(command), pipes.returncode))
        # if pipes.returncode != 0:
        #     return ExecutionStatus.objects.get(name="FAILED"), action_execution_info
        # return ExecutionStatus.objects.get(name="SUCCESS"), action_execution_info


    @staticmethod
    def apply_rule_batch(rule):
        return RuleAdmin.apply(rule, BatchJob.BATCH)


    @staticmethod
    def apply_rule_job(rule):
        return RuleAdmin.apply(rule, BatchJob.JOB)
