

class Event():
    job_status_code = 0
    batch_status_change = 1
    job_status_change = 2
    batch_duration = 3
    job_duration = 4
    batch_max_finish_time = 5
    job_max_finish_time = 6

    @staticmethod
    def get_name(id):
        events = ["job_status_code",
        "batch_status_change",
        "job_status_change",
        "batch_duration",
        "job_duration",
        "batch_max_finish_time",
        "job_max_finish_time"]

        return events[id]
