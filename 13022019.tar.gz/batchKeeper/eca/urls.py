from django.conf.urls import url, include

from . import views
from rest_framework import routers
from . import rest_views


router = routers.DefaultRouter()
router.register(r'action', rest_views.ActionViewSet)
router.register(r'batch_rule', rest_views.BatchRuleViewSet)
router.register(r'job_rule', rest_views.JobRuleViewSet)
router.register(r'action', rest_views.ActionViewSet)
router.register(r'condition', rest_views.ConditionViewSet)
router.register(r'batch_event', rest_views.BatchEventViewSet)
router.register(r'job_event', rest_views.JobEventViewSet)


urlpatterns = [
    url(r'v1/', include(router.urls)),
    url(r'^$', views.index, name='index'),
    url(r'create$', views.create, name='create'),
    url(r'^api-auth/', include('rest_framework.urls', namespace='rest_framework'))
]
