import os
from batch_keeper.settings import ECA_REPOSITORY_PATH, BK_API_DIR, MY_FQDN
import docker


class IM():
    client = docker.from_env()
    user_container = None
    users_path = "/var/www/bk_files/users"
    username = "bruno"
    container_scripts_directory = "/mnt/scripts"
    bk_api_dir = "/var/www/bk_api"

    def __init__(self):
        #self.image = self.client.images.pull('fedora:latest')
        users_path = self.users_path+"/"+self.username
        if not os.path.exists(users_path):
            os.makedirs(users_path)
        self.user_container = self.client.containers.create('fedora:latest',command="/bin/bash", tty=True,
            stdin_open=True, auto_remove=False, network_mode="host", volumes={
            '%s' % ECA_REPOSITORY_PATH: {'bind': self.container_scripts_directory, 'mode': 'rw'},
            '%s/%s' % (self.users_path, self.username): {'bind': '/mnt/user', 'mode': 'rw'},
            '%s' % (BK_API_DIR,): {'bind': self.bk_api_dir, 'mode': 'rw'},
            })
        self.user_container.start()
        exit_code, output = self.run_command("dnf install -y python3-pip")
        print(exit_code, output)
        print("===============")
        exit_code, output = self.run_command("pip3 install --user %s/bk_api.tar.gz" % (self.bk_api_dir,))
        print(exit_code, output)

    def create(self):
        pass

    def drop(self,):
        self.user_container.stop()
        self.user_container.remove()

    def run_command(self, command):
        print("---------------------------------")
        print(command)
        print("---------------------------------")
        exit_code, output = self.user_container.exec_run(command, environment={"BATCHKEEPER_FQDN": MY_FQDN})
        return exit_code, output

    def get_container_actions_directory(self):
        return self.container_scripts_directory+"/actions"

    def get_container_conditions_directory(self):
        return self.container_scripts_directory+"/conditions"
