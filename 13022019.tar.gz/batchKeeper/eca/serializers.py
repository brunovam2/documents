from rest_framework import serializers
from .models import Action, Condition, BatchRule, JobRule, BatchEvent, JobEvent


class ActionSerializer(serializers.ModelSerializer):
    class Meta:
        model = Action
        fields = ('id', 'nickname', 'description', 'filename', 'args', 'env_args')

    def create(self, validated_data):
        return Action.objects.create(**validated_data)

    def update(self, instance, validated_data):
        instance.id = validated_data.get('id', instance.id)
        instance.nickname = validated_data.get('nickname', instance.nickname)
        instance.description = validated_data.get('description', instance.description)
        instance.filename = validated_data.get('filename', instance.filename)
        instance.args = validated_data.get('args', instance.args)
        instance.env_args = validated_data.get('env_args', instance.env_args)

        instance.save()
        return instance


class ConditionSerializer(serializers.ModelSerializer):
    class Meta:
        model = Condition
        fields = ('id', 'nickname', 'description', 'filename', 'function_name', 'function_args')

    def create(self, validated_data):
        return Condition.objects.create(**validated_data)

    def update(self, instance, validated_data):
        instance.id = validated_data.get('id', instance.id)
        instance.nickname = validated_data.get('nickname', instance.nickname)
        instance.description = validated_data.get('description', instance.description)
        instance.filename = validated_data.get('filename', instance.filename)
        instance.args = validated_data.get('function_name', instance.args)
        instance.env_args = validated_data.get('function_args', instance.env_args)

        instance.save()
        return instance

class BatchRuleSerializer(serializers.ModelSerializer):
    class Meta:
        model = BatchRule
        fields = ('id', 'batch', 'event', 'condition', 'action')

    def create(self, validated_data):
        return BatchRule.objects.create(**validated_data)

    def update(self, instance, validated_data):
        instance.id = validated_data.get('id', instance.id)
        instance.Batch = validated_data.get('batch', instance.Batch)
        instance.event = validated_data.get('event', instance.event)
        instance.condition = validated_data.get('condition', instance.condition)
        instance.action = validated_data.get('action', instance.action)

        instance.save()
        return instance

class JobRuleSerializer(serializers.ModelSerializer):
    class Meta:
        model = JobRule
        fields = ('id', 'job', 'event', 'condition', 'action')

    def create(self, validated_data):
        return JobRule.objects.create(**validated_data)

    def update(self, instance, validated_data):
        instance.id = validated_data.get('id', instance.id)
        instance.job = validated_data.get('job', instance.job)
        instance.event = validated_data.get('event', instance.event)
        instance.condition = validated_data.get('condition', instance.condition)
        instance.action = validated_data.get('action', instance.action)

        instance.save()
        return instance

class BatchEventSerializer(serializers.ModelSerializer):
    class Meta:
        model = BatchEvent
        fields = ('id', 'name')

    def create(self, validated_data):
        return BatchEvent.objects.create(**validated_data)

    def update(self, instance, validated_data):
        instance.id = validated_data.get('id', instance.id)
        instance.nickname = validated_data.get('name', instance.nickname)

        instance.save()
        return instance

class JobEventSerializer(serializers.ModelSerializer):
    class Meta:
        model = JobEvent
        fields = ('id', 'name')

    def create(self, validated_data):
        return JobEvent.objects.create(**validated_data)

    def update(self, instance, validated_data):
        instance.id = validated_data.get('id', instance.id)
        instance.nickname = validated_data.get('name', instance.nickname)

        instance.save()
        return instance
