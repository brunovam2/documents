from rest_framework import viewsets
from .serializers import ActionSerializer, BatchRuleSerializer, JobRuleSerializer, ConditionSerializer, BatchEventSerializer, JobEventSerializer
from .models import Action, BatchRule, JobRule, Condition, BatchEvent, JobEvent


class ActionViewSet(viewsets.ModelViewSet):
    """
    API endpoint that allows groups to be viewed or edited.
    """
    queryset = Action.objects.all()
    serializer_class = ActionSerializer


class ConditionViewSet(viewsets.ModelViewSet):
    """
    API endpoint that allows groups to be viewed or edited.
    """
    queryset = Condition.objects.all()
    serializer_class = ConditionSerializer


class BatchRuleViewSet(viewsets.ModelViewSet):
    """
    API endpoint that allows groups to be viewed or edited.
    """
    queryset = BatchRule.objects.all()
    serializer_class = BatchRuleSerializer


class BatchEventViewSet(viewsets.ModelViewSet):
    """
    API endpoint that allows groups to be viewed or edited.
    """
    queryset = BatchEvent.objects.all()
    serializer_class = BatchEventSerializer


class JobRuleViewSet(viewsets.ModelViewSet):
    """
    API endpoint that allows groups to be viewed or edited.
    """
    queryset = JobRule.objects.all()
    serializer_class = JobRuleSerializer


class JobEventViewSet(viewsets.ModelViewSet):
    """
    API endpoint that allows groups to be viewed or edited.
    """
    queryset = JobEvent.objects.all()
    serializer_class = JobEventSerializer
