from django.apps import AppConfig


class EcaConfig(AppConfig):
    name = 'eca'
