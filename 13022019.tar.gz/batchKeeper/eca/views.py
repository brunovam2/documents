from django.shortcuts import render
# from django.http import HttpResponse
# from django.template import loader


# Create your views here.
def index(request):
    print("AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA")
    context = {}
    return render(request, 'eca/index2.html', context)

def create(request):
    context = {}
    return render(request, 'eca/index2.html', context)
