# batchKeeper

O BatchKeeper (BK) é uma ferramenta de workflow para processamento em lote com tomada de decisões automatizadas via regras ECA. O BK consegue tomar decisões automatizadas de acordo com as informações de execução dos processamentos executadas pelo próprio BK e também por informações escritas por monitoradores de logs na tabela de log do batchKeeper.

## Requisitos para funcionamento
* Configuração de SSH sem senha para qualquer host cadastrado
* Repositório do BatchKeeper na mesma máquina do BatchKeeper Server
* Path do BatchKeeper Client repository devidamente configurado no settings do BatchKeeper server

## BatchKeeper server

Este é o código principal do BatchKeeper, sendo dividido em dois apps: Scheduler e Rules

### Scheduler
Este app contém todos os models básicos (Host, Job, JobDependency, Resource e Batch e BatchGroup).

Cada Host representa uma máquina no Cluster. No cadastro de um Host, deve haver informações sobre seus recursos principais de hardware para que seja possível saber quais jobs poderão ser executados no mesmo. A informação do Hostname é utilizada na conexão com a mesma para execução das tarefas/jobs.

Uma batch é na verdade um lote e é composto por um ou mais jobs. Um batch é um modelo de um processo e cada job um subprocesso.

Em cada job são cadastradas as informações de execução de comandos e seus respectivos argumentos, além de definições básicas como o local onde estes serão executados e etc..

Dependencias entre jobs podem ser cadastradas em JobDependency. Agrupamentos de Batches para execução com uma ordem específica de execução podem ser feitos utilizando BatchGroups e BatchGroupExecutionOrder.

### Rules
Este é o módulo mais importante do BatchKeeper, implementando a lógica da tomada automática de decisões.
A tomada de decisões é feita via regras ECA (Event - Condition - Action). A regra ECA é utilizada para definir ações que deverão ser executadas na ocorrência de algum evento desde que uma certa condição seja satisfeita.
Ex.: Se a exportação do movimento da Marinha demorar mais do que X horas, está deverá ser abortada e o banco de dados restaurado de acordo com o dump mais recente.

Ex.: Se houver falta de espaço em disco na máquina no momento de algum processamento, este deverá ser abortado e um e-mail deverá ser enviado à Infra informando a respeito deste problema. O processamento deverá ser reconfigurado para ser executado no próximo dia.

Quando ocorre algum evento no BatchKeeper, é verificado se há regras vinculadas ao evento disparado. Caso exitam regras, as condições são executadas e, caso retornem True, as ações são executadas.

## BatchKeeper client repository
Este repositório é bem simples. Existem duas pastas, uma para os arquivos .py de ações e outro com os arquivos .py de condições.

### Ações
Uma ação é um script python que pode fazer qualquer coisa. Não são esperados retornos específicos de uma ação.

### Condições
Uma condição é uma função python. Toda condição deve retornar True ou False. Neste momento o desenvolvedor fica livre para fazer o que quiser dentro dessa função, inclusive para acessar o próprio banco de dados do BatchKeeper Server, executar comandos externos com o subprocess e etc...

## Erros conhecidos


## TODO
* Dependência entre jobs
* Conexão via SSH com IP e senha para os Hosts registrados.
