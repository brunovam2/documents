import os
import sys
from subprocess import Popen, PIPE
import subprocess
import multiprocessing
from http.server import HTTPServer, BaseHTTPRequestHandler
import json
import time
import requests
import socket, errno


BK_SERVER = None
JOB_PID = None
MY_PID = os.getpid()
JOB_EXECUTION_UUID = None
MY_PORT = None


def send_info2bk_server(bk_server, relative_url, data):
    requests.packages.urllib3.disable_warnings()
    session = requests.Session()
    session.trust_env = False
    r = session.post("http://%s/%s" % (bk_server, relative_url), data=json.dumps(data), verify=False)
    if r.status_code != 200:
        return False, r.status_code
    else:
        return True, r.status_code

def inform_execution_configs(bk_server, data):
    return send_info2bk_server(bk_server, "executor/execution_configs", data)


def inform_execution(bk_server, data):
    return send_info2bk_server(bk_server, "executor/execution_result", data)


def find_open_port():
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.bind(('', 0))
    addr = s.getsockname()
    port = addr[1]
    s.close()
    return port


class ExampleJSONHandler(BaseHTTPRequestHandler):
    def do_POST(self):
        len = int(self.headers.get('Content-Length'))
        data = json.loads(self.rfile.read(len).decode('utf-8'))
        self.send_response(200)
        self.send_header(b'Content-type', b'text/plain')
        self.end_headers()
        if data['action'] == 'TERMINATE':
            run("kill %d" % JOB_PID)
            self.wfile.write("%d killed".encode('utf-8') % JOB_PID,)

def run(command, bk_server, JOB_EXECUTION_UUID):
    process = Popen(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE, shell=True)
    JOB_PID = process.pid
    # while True:
    #     line = process.stdout.readline().rstrip()
    #     if not line:
    #         break
    #     yield line
    std_out, std_err = process.communicate()
    output = str(std_out, errors='ignore')
    output_err = str(std_err, errors='ignore')
    status_code = process.returncode

    data = {"job_execution_uuid": JOB_EXECUTION_UUID, "job_pid": JOB_PID, "output": output, "output_err": output_err, "exit_code": status_code}
    print(data)
    inform_execution(bk_server, data)
    sys.exit(0)
    return None

def main():
    BK_SERVER = sys.argv[1]
    command = sys.argv[2]
    JOB_EXECUTION_UUID = sys.argv[3]

    MY_PORT = None
    print(BK_SERVER)
    while not MY_PORT:
        print("Waiting for an available port...")
        MY_PORT = find_open_port()
        time.sleep(5)

    #inform command pid, my PID, my port, 
    data = {"job_execution_uuid": JOB_EXECUTION_UUID, "agent_pid": MY_PID, "agent_port": MY_PORT}
    inform_execution_configs(BK_SERVER, data)
    
    server = HTTPServer(('localhost', MY_PORT), ExampleJSONHandler)
    p = multiprocessing.Process(target=run, args=(command,BK_SERVER,JOB_EXECUTION_UUID))
    p.start()

    server.serve_forever()

if __name__ == "__main__":
    main()
    # for path in run("ping -c 5 google.com"):
    #     print (path)
