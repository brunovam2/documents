def teste():
    return True
