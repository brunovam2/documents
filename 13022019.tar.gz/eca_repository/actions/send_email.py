import sys, os, django
#from settings import BK_PATH, PRODUCAO
#sys.path.append(BK_PATH)
BK_PATH = "/var/www/producao/batchKeeper"
sys.path.append(BK_PATH)
PRODUCAO=True
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "batch_keeper.settings")
django.setup()

import argparse
from scheduler.models import Batch, BatchStatus, Job, JobStatus
from django.core.mail import send_mail


def main():
    parser = argparse.ArgumentParser(description='Send e-mails')
    parser.add_argument('-receiver', help='Destination')
    parser.add_argument('-sender', help='Destination')
    parser.add_argument('-subject', help='Subject of the email')
    parser.add_argument('-msg', help='E-mail message')

    args = parser.parse_args()
    mail(args.sender,  [args.receiver], args.subject, args.msg)

def mail(sender, receiver, subject, msg):
    if PRODUCAO:
        send_mail(
            subject,#Subject
            msg,
            sender,
            receiver,
            fail_silently=False,
        )
    print("Email enviado")

if __name__ == "__main__":
    main()
