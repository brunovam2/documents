import sys, os, django
#from settings import BK_PATH, PRODUCAO
#sys.path.append(BK_PATH)
BK_PATH = "/var/www/producao/batchKeeper"
sys.path.append(BK_PATH)
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "batch_keeper.settings")
django.setup()


from scheduler.models import (
    Batch,
    Job
)
