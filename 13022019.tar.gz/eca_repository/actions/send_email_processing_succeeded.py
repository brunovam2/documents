import sys, os, django
#from settings import BK_PATH, PRODUCAO
#sys.path.append(BK_PATH)
BK_PATH = "/var/www/producao/batchKeeper"
sys.path.append(BK_PATH)
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "batch_keeper.settings")
django.setup()

import argparse
from django.core.exceptions import ObjectDoesNotExist
from scheduler.models import Batch, BatchStatus, Job, JobStatus
from send_email import mail


parser = argparse.ArgumentParser(description='Send e-mails')

parser.add_argument('-job', help='Related job')
parser.add_argument('-batch', help='Related batch')
parser.add_argument('-log', help='Related log')


args = parser.parse_args()

sender="automatizacao.interno@zetrasoft.com.br"
receiver="bruno.machado@zetrasoft.com.br"

msg = ""
if args.job:
    try:
        j = Job.objects.get(id=args.job)
    except ObjectDoesNotExist:
        print("Job not found")
        sys.exit(151)
    subject = "Erro ao executar job"
    print("STATUS:"+str(j.status))
    msg = "O Job %s acabou de mudar de status para %s\n\Saida:%s\n%s" % (j.nickname, JobStatus.get_name(j.status), j.output, j.output_err)
elif args.batch:
    try:
        t = Batch.objects.get(id=args.batch)
    except ObjectDoesNotExist:
        print("Batch not found")
        sys.exit(150)
    subject = "Acompanhamento de status de tarefa"
    msg = "A tarefa %s acabou de mudar de status para %s." % (t.nickname, BatchStatus.get_name(t.status))

mail(sender, [receiver], subject, msg)
print("Para:%s\nAssunto:%s\n\nMensagem:%s" %(receiver, subject, msg))
