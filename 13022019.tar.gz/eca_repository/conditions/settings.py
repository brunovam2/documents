PRODUCAO = True
if PRODUCAO:
    BK_PATH = "/var/www/producao/batchKeeper"
else:
    BK_PATH = "/var/www/desenv/batchKeeper"
