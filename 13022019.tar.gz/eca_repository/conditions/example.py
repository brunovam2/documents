import sys, os, django
from settings import BK_PATH, PRODUCAO
sys.path.append(BK_PATH)
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "batch_keeper.settings")
django.setup()

from django.core.exceptions import ObjectDoesNotExist
from scheduler.models import Batch, BatchStatus, Job, JobStatus


def example_of_condition(**kwargs):
    if "job" in kwargs:
        job = Job.objects.get(id=kwargs["job"])
        if job.status == JobStatus.FAILED:
            return True
    return False
