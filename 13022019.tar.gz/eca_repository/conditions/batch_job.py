import sys, os, django
#from settings import BK_PATH, PRODUCAO
#sys.path.append(BK_PATH)
BK_PATH = "/var/www/producao/batchKeeper"
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "batch_keeper.settings")
django.setup()

from django.core.exceptions import ObjectDoesNotExist
from scheduler.models import Batch, BatchStatus, Job, JobStatus


def batch_job_failed(**kwargs):
    if "job" in kwargs:
        job = Job.objects.get(id=kwargs["job"])
        if job.status == JobStatus.FAILED:
            return True

    if "batch" in kwargs:
        batch = Batch.objects.get(id=kwargs["batch"])
        if batch.status == BatchStatus.FAILED:
            return True

    return False

def batch_job_succeeded(**kwargs):
    if "job" in kwargs:
        job = Job.objects.get(id=kwargs["job"])
        if job.status == JobStatus.EXECUTED:
            return True

    if "batch" in kwargs:
        batch = Batch.objects.get(id=kwargs["batch"])
        if batch.status == BatchStatus.SUCCESS:
            return True

    return False
