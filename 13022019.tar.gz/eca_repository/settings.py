SERVER_PATH="/home/brunovam/code/batchKeeper"

